/*
 * Pixel Music (2026)
 * © zlgskt6 — github.com/zlgskt6
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 *
 * Based on ArchiveTune (2026)
 * © Rukamori — github.com/rukamori
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.zlgskt6.pixelmusic.playback.queues

import androidx.media3.common.MediaItem
import com.zlgskt6.pixelmusic.db.MusicDatabase
import com.zlgskt6.pixelmusic.extensions.toMediaItem
import com.zlgskt6.pixelmusic.innertube.YouTube
import com.zlgskt6.pixelmusic.innertube.models.WatchEndpoint
import com.zlgskt6.pixelmusic.models.MediaMetadata
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.first

class LocalMixQueue(
    private val database: MusicDatabase,
    private val playlistId: String,
    private val maxMixSize: Int = 500,
) : Queue {
    override val preloadItem: MediaMetadata? = null

    override suspend fun getInitialStatus(): Queue.Status = withContext(Dispatchers.IO) {
        val playlistSongEntities = database.playlistSongs(playlistId).first()
        val playlistSongIds = playlistSongEntities.map { it.map.songId }

        val relatedSongs = playlistSongIds.flatMap { songId ->
            database.relatedSongs(songId)
        }
        val uniqueRelated = relatedSongs.filter { song -> song.id !in playlistSongIds }.distinctBy { it.id }
        val finalMix = uniqueRelated.take(maxMixSize)

        if (finalMix.isNotEmpty()) {
            return@withContext Queue.Status(
                title = "Mix from Playlist",
                items = finalMix.map { it.toMediaItem() },
                mediaItemIndex = 0,
            )
        }

        val seedSongId = playlistSongIds.firstOrNull()
            ?: return@withContext Queue.Status(title = "Mix from Playlist", items = emptyList(), mediaItemIndex = 0)

        val nextResult = YouTube.next(WatchEndpoint(videoId = seedSongId)).getOrNull()
        val fromNext = nextResult?.items
            ?.map { it.toMediaItem() }
            ?.filter { it.mediaId !in playlistSongIds }
            .orEmpty()

        val fromRelated = nextResult?.relatedEndpoint?.let { endpoint ->
            YouTube.related(endpoint).getOrNull()?.songs
                ?.map { it.toMediaItem() }
                ?.filter { it.mediaId !in playlistSongIds }
        }.orEmpty()

        val onlineMix = (fromNext + fromRelated)
            .distinctBy { it.mediaId }
            .take(maxMixSize)

        Queue.Status(
            title = "Mix from Playlist",
            items = onlineMix,
            mediaItemIndex = 0,
        )
    }

    override fun hasNextPage(): Boolean = false
    override suspend fun nextPage(): List<MediaItem> = emptyList()
}
