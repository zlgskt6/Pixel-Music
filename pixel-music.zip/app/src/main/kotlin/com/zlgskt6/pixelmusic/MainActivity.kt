/*
 * Pixel Music (2026)
 * © zlgskt6 — github.com/zlgskt6
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 *
 * Based on ArchiveTune (2026)
 * © Rukamori — github.com/rukamori
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package com.zlgskt6.pixelmusic

import android.annotation.SuppressLint
import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.os.IBinder
import android.view.View
import android.view.WindowManager
import android.webkit.MimeTypeMap
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.add
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialogDefaults
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.PlainTooltip
import androidx.compose.material3.RichTooltip
import androidx.compose.material3.TooltipBox
import androidx.compose.material3.TooltipDefaults
import androidx.compose.material3.rememberTooltipState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.core.content.ContextCompat
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SearchBarDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.adaptive.currentWindowAdaptiveInfo
import androidx.compose.material3.contentColorFor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.blur
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.fastAny
import androidx.compose.ui.util.fastFirstOrNull
import androidx.compose.ui.util.fastForEach
import androidx.compose.ui.zIndex
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.net.toUri
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.datastore.preferences.core.edit
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata.MEDIA_TYPE_MUSIC
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.window.core.layout.WindowSizeClass
import androidx.core.content.IntentCompat
import androidx.compose.ui.layout.ContentScale
import coil3.compose.AsyncImage
import coil3.imageLoader
import coil3.request.ImageRequest
import coil3.request.allowHardware
import coil3.toBitmap
import com.zlgskt6.pixelmusic.constants.AccountImageUrlKey
import com.zlgskt6.pixelmusic.constants.InnerTubeCookieKey
import com.zlgskt6.pixelmusic.constants.RecapBubbleDismissedKey
import com.zlgskt6.pixelmusic.innertube.utils.hasYouTubeLoginCookie
import com.valentinilk.shimmer.LocalShimmerTheme
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import com.zlgskt6.pixelmusic.utils.PreferenceStore
import com.zlgskt6.pixelmusic.utils.isLowRamDevice
import kotlinx.coroutines.withContext
import com.zlgskt6.pixelmusic.constants.AppBarHeight
import com.zlgskt6.pixelmusic.constants.AppFontPreference
import com.zlgskt6.pixelmusic.constants.AppLanguageKey
import com.zlgskt6.pixelmusic.constants.CustomFontUriKey
import com.zlgskt6.pixelmusic.constants.CustomThemeColorKey
import com.zlgskt6.pixelmusic.constants.DarkModeKey
import com.zlgskt6.pixelmusic.constants.DefaultOpenTabKey
import com.zlgskt6.pixelmusic.constants.DisableAnimationsKey
import com.zlgskt6.pixelmusic.constants.DisableBlurKey
import com.zlgskt6.pixelmusic.constants.DisableScreenshotKey
import com.zlgskt6.pixelmusic.constants.DynamicThemeKey
import com.zlgskt6.pixelmusic.constants.FloatingToolbarBottomPadding
import com.zlgskt6.pixelmusic.constants.FloatingToolbarHeight
import com.zlgskt6.pixelmusic.constants.FloatingToolbarHorizontalPadding
import com.zlgskt6.pixelmusic.constants.FontPreferenceKey
import com.zlgskt6.pixelmusic.constants.MiniPlayerBottomSpacing
import com.zlgskt6.pixelmusic.constants.MiniPlayerHeight
import com.zlgskt6.pixelmusic.constants.MiniPlayerLastAnchorKey
import com.zlgskt6.pixelmusic.constants.NavigationBarAnimationSpec
import com.zlgskt6.pixelmusic.constants.PauseSearchHistoryKey
import com.zlgskt6.pixelmusic.constants.PureBlackKey
import com.zlgskt6.pixelmusic.constants.PlayerBackgroundStyle
import com.zlgskt6.pixelmusic.constants.PlayerBackgroundStyleKey
import com.zlgskt6.pixelmusic.constants.PlayerDesignStyle
import com.zlgskt6.pixelmusic.constants.PlayerDesignStyleKey
import com.zlgskt6.pixelmusic.constants.RemindAfterKey
import com.zlgskt6.pixelmusic.constants.SYSTEM_DEFAULT
import com.zlgskt6.pixelmusic.constants.SearchSource
import com.zlgskt6.pixelmusic.constants.SearchSourceKey
import com.zlgskt6.pixelmusic.constants.PixelMusicOnboardingCompletedKey
import com.zlgskt6.pixelmusic.constants.StopMusicOnTaskClearKey
import com.zlgskt6.pixelmusic.constants.UseSystemFontKey
import com.zlgskt6.pixelmusic.db.MusicDatabase
import com.zlgskt6.pixelmusic.db.entities.SearchHistory
import com.zlgskt6.pixelmusic.db.entities.Album
import com.zlgskt6.pixelmusic.db.entities.Artist
import com.zlgskt6.pixelmusic.db.entities.Playlist
import com.zlgskt6.pixelmusic.db.entities.Song

import com.zlgskt6.pixelmusic.innertube.YouTube
import com.zlgskt6.pixelmusic.innertube.models.AlbumItem
import com.zlgskt6.pixelmusic.innertube.models.ArtistItem
import com.zlgskt6.pixelmusic.innertube.models.PlaylistItem
import com.zlgskt6.pixelmusic.innertube.models.SongItem
import com.zlgskt6.pixelmusic.extensions.toMediaItem
import com.zlgskt6.pixelmusic.models.toMediaMetadata
import com.zlgskt6.pixelmusic.musicrecognition.ACTION_MUSIC_RECOGNITION
import com.zlgskt6.pixelmusic.musicrecognition.MusicRecognitionRoute
import com.zlgskt6.pixelmusic.musicrecognition.openMusicRecognition
import com.zlgskt6.pixelmusic.playback.DownloadUtil
import com.zlgskt6.pixelmusic.playback.MusicService
import com.zlgskt6.pixelmusic.playback.MusicService.MusicBinder
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import com.zlgskt6.pixelmusic.constants.EnableHapticFeedbackKey
import com.zlgskt6.pixelmusic.constants.UpdateChannel
import com.zlgskt6.pixelmusic.constants.UpdateChannelKey
import com.zlgskt6.pixelmusic.utils.rememberPreference
import com.zlgskt6.pixelmusic.playback.PlayerConnection
import com.zlgskt6.pixelmusic.playback.queues.LocalAlbumRadio
import com.zlgskt6.pixelmusic.playback.queues.ListQueue
import com.zlgskt6.pixelmusic.playback.queues.Queue
import com.zlgskt6.pixelmusic.playback.queues.YouTubeAlbumRadio
import com.zlgskt6.pixelmusic.playback.queues.YouTubeQueue
import com.zlgskt6.pixelmusic.ui.component.BottomSheetMenu
import com.zlgskt6.pixelmusic.ui.component.BottomSheetPage
import com.zlgskt6.pixelmusic.ui.component.SettingsBottomSheet
import com.zlgskt6.pixelmusic.ui.component.COLLAPSED_ANCHOR
import com.zlgskt6.pixelmusic.ui.component.CreatePlaylistDialog
import com.zlgskt6.pixelmusic.ui.component.DISMISSED_ANCHOR
import com.zlgskt6.pixelmusic.ui.component.EXPANDED_ANCHOR
import com.zlgskt6.pixelmusic.ui.component.FloatingNavigationToolbar
import com.zlgskt6.pixelmusic.ui.component.IconButton
import com.zlgskt6.pixelmusic.ui.component.LocalBottomSheetPageState
import com.zlgskt6.pixelmusic.ui.component.LocalMenuState
import com.zlgskt6.pixelmusic.ui.component.NetworkStatusBanner
import com.zlgskt6.pixelmusic.ui.component.TvNavigationRail
import com.zlgskt6.pixelmusic.ui.component.MarkdownText
import com.zlgskt6.pixelmusic.ui.component.TopSearch
import com.zlgskt6.pixelmusic.ui.component.rememberBottomSheetState
import com.zlgskt6.pixelmusic.ui.component.shimmer.ShimmerTheme
import com.zlgskt6.pixelmusic.ui.menu.YouTubeSongMenu
import com.zlgskt6.pixelmusic.ui.player.BottomSheetPlayer
import com.zlgskt6.pixelmusic.ui.screens.LOGIN_URL_ARGUMENT
import com.zlgskt6.pixelmusic.ui.screens.Screens
import com.zlgskt6.pixelmusic.ui.screens.buildLoginRoute
import com.zlgskt6.pixelmusic.ui.screens.navigationBuilder
import com.zlgskt6.pixelmusic.ui.screens.search.LocalSearchScreen
import com.zlgskt6.pixelmusic.ui.screens.search.OnlineSearchScreen
import com.zlgskt6.pixelmusic.ui.screens.search.OnlineSearchResultArgument
import com.zlgskt6.pixelmusic.ui.screens.search.OnlineSearchResultRoutePrefix
import com.zlgskt6.pixelmusic.ui.screens.search.decodeOnlineSearchQuery
import com.zlgskt6.pixelmusic.ui.screens.search.onlineSearchResultRoute
import com.zlgskt6.pixelmusic.ui.screens.settings.DarkMode
import com.zlgskt6.pixelmusic.ui.screens.settings.DiscordPresenceManager
import com.zlgskt6.pixelmusic.ui.screens.settings.NavigationTab
import com.zlgskt6.pixelmusic.ui.theme.PixelMusicTheme
import com.zlgskt6.pixelmusic.ui.theme.ColorSaver
import com.zlgskt6.pixelmusic.ui.theme.DefaultThemeColor
import com.zlgskt6.pixelmusic.ui.theme.extractThemeColor
import com.zlgskt6.pixelmusic.ui.utils.appBarScrollBehavior
import com.zlgskt6.pixelmusic.ui.utils.backToMain
import com.zlgskt6.pixelmusic.ui.utils.getGreetingResId
import com.zlgskt6.pixelmusic.ui.utils.resetHeightOffset
import com.zlgskt6.pixelmusic.utils.SyncUtils
import com.zlgskt6.pixelmusic.utils.Updater
import com.zlgskt6.pixelmusic.utils.dataStore
import com.zlgskt6.pixelmusic.utils.get
import com.zlgskt6.pixelmusic.utils.getAsync
import com.zlgskt6.pixelmusic.utils.isRecapTimePeriod
import com.zlgskt6.pixelmusic.utils.rememberEnumPreference
import com.zlgskt6.pixelmusic.utils.rememberPreference
import com.zlgskt6.pixelmusic.utils.reportException
import com.zlgskt6.pixelmusic.utils.setAppLocale
import com.zlgskt6.pixelmusic.viewmodels.HomeViewModel
import com.zlgskt6.pixelmusic.viewmodels.NetworkBannerViewModel
import java.util.Locale
import javax.inject.Inject
import kotlin.random.Random
import kotlin.time.Duration.Companion.days

@Suppress("DEPRECATION", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE")
@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    @Inject
    lateinit var database: MusicDatabase

    @Inject
    lateinit var downloadUtil: DownloadUtil

    @Inject
    lateinit var syncUtils: SyncUtils

    private lateinit var navController: NavHostController
    private var pendingIntent: Intent? = null
    private var pendingDeepLinkQueue: Queue? = null
    private var pendingVoiceSearchQuery: String? = null
    private var pendingTogetherJoinLink: String? = null
    private var latestVersionName by mutableStateOf(BuildConfig.VERSION_NAME)

    private var playerConnection by mutableStateOf<PlayerConnection?>(null)
    private var isMusicServiceBound = false
    
    private val serviceConnection =
        object : ServiceConnection {
            override fun onServiceConnected(
                name: ComponentName?,
                service: IBinder?,
            ) {
                isMusicServiceBound = true
                if (service is MusicBinder) {
                    playerConnection =
                        PlayerConnection(this@MainActivity, service, database, lifecycleScope)
                    playPendingDeepLinkQueueIfReady()
                    playPendingVoiceSearchIfReady()
                    joinPendingTogetherIfReady()
                }
            }

            override fun onServiceDisconnected(name: ComponentName?) {
                isMusicServiceBound = false
                playerConnection?.dispose()
                playerConnection = null
            }
        }

    private fun playPendingDeepLinkQueueIfReady() {
        val pending = pendingDeepLinkQueue ?: return
        val connection = playerConnection ?: return
        pendingDeepLinkQueue = null
        connection.playQueue(pending)
    }

    private fun playPendingVoiceSearchIfReady() {
        val query = pendingVoiceSearchQuery ?: return
        val connection = playerConnection ?: return
        pendingVoiceSearchQuery = null
        connection.playFromVoiceSearch(query)
    }

    private fun joinPendingTogetherIfReady() {
        val pending = pendingTogetherJoinLink ?: return
        val connection = playerConnection ?: return
        pendingTogetherJoinLink = null
        lifecycleScope.launch(Dispatchers.IO) {
            val displayName =
                runCatching { dataStore.data.first()[com.zlgskt6.pixelmusic.constants.TogetherDisplayNameKey] }
                    .getOrNull()
                    ?.trim()
                    .orEmpty()
                    .ifBlank { Build.MODEL ?: getString(R.string.app_name) }
            withContext(Dispatchers.Main) {
                connection.service.joinTogether(pending, displayName)
            }
        }
    }

    private suspend fun awaitRestorablePlayback(connection: PlayerConnection): Boolean {
        repeat(15) {
            if (
                connection.player.currentMediaItem != null ||
                connection.player.mediaItemCount > 0 ||
                connection.mediaMetadata.value != null
            ) {
                return true
            }
            delay(100)
        }

        return (
            connection.player.currentMediaItem != null ||
                connection.player.mediaItemCount > 0 ||
                connection.mediaMetadata.value != null
            )
    }

    override fun onStart() {
        super.onStart()
        isMusicServiceBound =
            bindService(
                Intent(this, MusicService::class.java),
                serviceConnection,
                Context.BIND_AUTO_CREATE
            )
        playPendingDeepLinkQueueIfReady()
    }

    private fun safeUnbindMusicService() {
        if (!isMusicServiceBound) return
        try {
            unbindService(serviceConnection)
        } catch (e: IllegalArgumentException) {
        } catch (e: Exception) {
            reportException(e)
        } finally {
            isMusicServiceBound = false
        }
    }

    override fun onStop() {
        safeUnbindMusicService()
        super.onStop()
    }

    override fun onDestroy() {
        super.onDestroy()
        // Only clear/stop presence when the activity is actually finishing (not on rotation)
        // and do not clear it for transient configuration changes.
        if (isFinishing && !isChangingConfigurations) {
            try { DiscordPresenceManager.stop() } catch (_: Exception) {}
        }

        val shouldStopOnTaskClear =
            if (!isFinishing) {
                false
            } else {
                dataStore.get(StopMusicOnTaskClearKey, false)
            }

        if (shouldStopOnTaskClear) {
            playerConnection?.service?.stopAndClearPlayback(clearPersistentState = true)
            safeUnbindMusicService()
            stopService(Intent(this, MusicService::class.java))
            playerConnection = null
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (::navController.isInitialized) {
            handleDeepLinkIntent(intent, navController)
        } else {
            pendingIntent = intent
        }
    }

    @SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_LTR
        WindowCompat.setDecorFitsSystemWindows(window, false)

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            val initialLocale = PreferenceStore.get(AppLanguageKey)
                ?.takeUnless { it == SYSTEM_DEFAULT }
                ?.let { Locale.forLanguageTag(it) }
                ?: Locale.getDefault()
            setAppLocale(this, initialLocale)

            lifecycleScope.launch(Dispatchers.IO) {
                runCatching {
                    dataStore.data.first()[AppLanguageKey]
                }.onSuccess { lang ->
                    val targetLocale = lang
                        ?.takeUnless { it == SYSTEM_DEFAULT }
                        ?.let { Locale.forLanguageTag(it) }
                        ?: Locale.getDefault()
                    if (targetLocale != initialLocale) {
                        withContext(Dispatchers.Main) {
                            setAppLocale(this@MainActivity, targetLocale)
                            recreate()
                        }
                    }
                }
            }
        }
        
        lifecycleScope.launch(Dispatchers.IO) {
            dataStore.data
                .map { it[DisableScreenshotKey] ?: false }
                .distinctUntilChanged()
                .collectLatest {
                    withContext(Dispatchers.Main) {
                        if (it) {
                            window.setFlags(
                                WindowManager.LayoutParams.FLAG_SECURE,
                                WindowManager.LayoutParams.FLAG_SECURE,
                            )
                        } else {
                            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                        }
                    }
                }
        }

        setContent {
            val notificationPermissionLauncher =
                rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
                    if (isGranted) {
                        playerConnection?.service?.refreshPlaybackNotification()
                    }
                }

            val updateChannel by rememberEnumPreference(UpdateChannelKey, defaultValue = UpdateChannel.STABLE)

            LaunchedEffect(Unit) {
                val isOnboardingDone = PreferenceStore.get(PixelMusicOnboardingCompletedKey) ?: false
                if (isOnboardingDone && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }

                while (playerConnection == null) {
                    delay(100)
                }
                delay(500)

                if (
                    BuildConfig.UPDATER_AVAILABLE &&
                    System.currentTimeMillis() - Updater.lastCheckTime > 1.days.inWholeMilliseconds
                ) {
                    val channelString = withContext(Dispatchers.IO) { dataStore.data.first()[UpdateChannelKey] }
                    val actualChannel = channelString?.let {
                        try { UpdateChannel.valueOf(it) } catch (_: IllegalArgumentException) { null }
                    } ?: UpdateChannel.STABLE

                    if (actualChannel != UpdateChannel.NIGHTLY) {
                        val versionResult = when (actualChannel) {
                            UpdateChannel.DAILY_NIGHTLY -> Updater.getLatestDailyNightlyVersionName()
                            else -> Updater.getLatestVersionName()
                        }
                        versionResult.onSuccess {
                            if (Updater.isUpdateAvailable(it, BuildConfig.VERSION_NAME)) {
                                latestVersionName = it
                            }
                        }
                    }
                }
                com.zlgskt6.pixelmusic.utils.UpdateNotificationManager.checkForUpdates(this@MainActivity)
            }

                    // Use remembered instances so the same state object is used everywhere
                    // (previously retrieving the composition local directly created different
                    // instances in different composition scopes which caused the update
                    // bottom sheet to not appear and overlay interactions to be blocked).
                    val bottomSheetPageState = remember { com.zlgskt6.pixelmusic.ui.component.BottomSheetPageState() }
                    val menuState = remember { com.zlgskt6.pixelmusic.ui.component.MenuState() }
                    val uriHandler = LocalUriHandler.current
                    val releaseNotesState = remember { mutableStateOf<String?>(null) }
                    val updateSheetContent: @Composable ColumnScope.() -> Unit = { // receiver: ColumnScope
                        Text(
                            text = stringResource(R.string.new_update_available),
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                            modifier = Modifier.padding(top = 16.dp)
                        )

                        Spacer(Modifier.height(8.dp))

                        androidx.compose.material3.OutlinedButton(
                            onClick = {},
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                                horizontal = 5.dp,
                                vertical = 5.dp
                            ),
                            shapes = ButtonDefaults.shapes(),
                        ) {
                            Text(text = latestVersionName, style = MaterialTheme.typography.labelLarge)
                        }

                        Spacer(Modifier.height(12.dp))

                        Box(modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false)
                            .verticalScroll(rememberScrollState())
                        ) {
                            val notes = releaseNotesState.value
                            if (notes != null && notes.isNotBlank()) {
                                MarkdownText(
                                    markdown = notes,
                                    modifier = Modifier
                                        .fillMaxWidth().padding(end = 8.dp),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            } else {
                                val currentVer = BuildConfig.VERSION_NAME
                                val latestVer = latestVersionName.removePrefix("v")
                                val changelogUrl = "https://github.com/zlgskt6/Pixel-Music/compare/v${currentVer}...v${latestVer}"
                                val changelogLabel = "Full Changelog: v${currentVer}...v${latestVer}"
                                Text(
                                    text = changelogLabel,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = MaterialTheme.colorScheme.primary,
                                        textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline,
                                    ),
                                    modifier = Modifier.clickable {
                                        try { uriHandler.openUri(changelogUrl) } catch (_: Exception) {}
                                    },
                                )
                            }
                        }

                        Spacer(Modifier.height(12.dp))

                        androidx.compose.material3.Button(
                            onClick = {
                                try {
                                    val downloadUrl = when (updateChannel) {
                                        UpdateChannel.DAILY_NIGHTLY -> Updater.getLatestDailyNightlyDownloadUrl()
                                        UpdateChannel.NIGHTLY -> Updater.getLatestNightlyDownloadUrl()
                                        UpdateChannel.STABLE -> Updater.getLatestDownloadUrl()
                                    }
                                    uriHandler.openUri(downloadUrl)
                                } catch (_: Exception) {}
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shapes = ButtonDefaults.shapes(),
                        ) {
                            Text(text = stringResource(R.string.update_text))
                        }
                    }

                    // fetch release notes and show sheet when a new version is detected
                    LaunchedEffect(latestVersionName) {
                        if (
                            BuildConfig.UPDATER_AVAILABLE &&
                            Updater.isUpdateAvailable(latestVersionName, BuildConfig.VERSION_NAME)
                        ) {
                            val releaseNotesResult = when (updateChannel) {
                                UpdateChannel.DAILY_NIGHTLY -> Updater.getLatestDailyNightlyReleaseNotes()
                                else -> Updater.getLatestReleaseNotes()
                            }
                            releaseNotesResult.onSuccess {
                                releaseNotesState.value = it
                            }.onFailure {
                                releaseNotesState.value = null
                            }

                            bottomSheetPageState.show(updateSheetContent)
                        }
                    }

            val enableDynamicTheme by rememberPreference(DynamicThemeKey, defaultValue = true)
            val customThemeColorValue by rememberPreference(CustomThemeColorKey, defaultValue = "default")
            val darkTheme by rememberEnumPreference(DarkModeKey, defaultValue = DarkMode.AUTO)
            val defaultDisableAnimations = remember(this@MainActivity) { applicationContext.isLowRamDevice() }
            val disableAnimations by rememberPreference(
                DisableAnimationsKey,
                defaultValue = defaultDisableAnimations,
            )
            val fontPreference by rememberEnumPreference(FontPreferenceKey, defaultValue = AppFontPreference.DEFAULT)
            val customFontUri by rememberPreference(CustomFontUriKey, defaultValue = "")
            val legacyUseSystemFont by rememberPreference(UseSystemFontKey, defaultValue = false)
            val isSystemInDarkTheme = isSystemInDarkTheme()
            val useDarkTheme =
                remember(darkTheme, isSystemInDarkTheme) {
                    if (darkTheme == DarkMode.AUTO) isSystemInDarkTheme else darkTheme == DarkMode.ON
                }
            val pureBlackEnabled by rememberPreference(PureBlackKey, defaultValue = false)
            val pureBlack = pureBlackEnabled && useDarkTheme

            val customThemeSeedPalette = remember(customThemeColorValue) {
                if (customThemeColorValue.startsWith("#")) {
                    null
                } else if (customThemeColorValue.startsWith("seedPalette:")) {
                    com.zlgskt6.pixelmusic.ui.theme.ThemeSeedPaletteCodec.decodeFromPreference(customThemeColorValue)
                } else {
                    com.zlgskt6.pixelmusic.ui.screens.settings.ThemePalettes
                        .findById(customThemeColorValue)
                        ?.let {
                            com.zlgskt6.pixelmusic.ui.theme.ThemeSeedPalette(
                                primary = it.primary,
                                secondary = it.secondary,
                                tertiary = it.tertiary,
                                neutral = it.neutral,
                            )
                        }
                }
            }

            val customThemeColor = remember(customThemeColorValue, customThemeSeedPalette) {
                if (customThemeColorValue.startsWith("#")) {
                    try {
                        val colorString = customThemeColorValue.removePrefix("#")
                        Color(android.graphics.Color.parseColor("#$colorString"))
                    } catch (e: Exception) {
                        DefaultThemeColor
                    }
                } else {
                    customThemeSeedPalette?.primary ?: DefaultThemeColor
                }
            }

            var themeColor by rememberSaveable(stateSaver = ColorSaver) {
                mutableStateOf(DefaultThemeColor)
            }

            LaunchedEffect(legacyUseSystemFont) {
                if (!legacyUseSystemFont) return@LaunchedEffect
                val preferences = dataStore.data.first()
                if (preferences[FontPreferenceKey] == null) {
                    dataStore.edit { it[FontPreferenceKey] = AppFontPreference.SYSTEM.name }
                }
            }

            LaunchedEffect(playerConnection, enableDynamicTheme, isSystemInDarkTheme, customThemeColor) {
                val playerConnection = playerConnection
                if (!enableDynamicTheme || playerConnection == null) {
                    themeColor = if (!enableDynamicTheme) customThemeColor else DefaultThemeColor
                    return@LaunchedEffect
                }
                playerConnection.service.currentMediaMetadata.collectLatest { song ->
                    if (song != null) {
                        withContext(Dispatchers.Default) {
                            try {
                                val result = imageLoader.execute(
                                    ImageRequest
                                        .Builder(this@MainActivity)
                                        .data(song.thumbnailUrl)
                                        .allowHardware(false)
                                        .build(),
                                )
                                val extractedColor = result.image?.toBitmap()?.extractThemeColor()
                                withContext(Dispatchers.Main) {
                                    themeColor = extractedColor ?: DefaultThemeColor
                                }
                            } catch (e: Exception) {
                                withContext(Dispatchers.Main) {
                                    themeColor = DefaultThemeColor
                                }
                            }
                        }
                    } else {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            themeColor = DefaultThemeColor
                        } else {
                            themeColor = customThemeColor
                        }
                    }
                }
            }

            PixelMusicTheme(
                darkTheme = useDarkTheme,
                pureBlack = pureBlack,
                themeColor = themeColor,
                seedPalette = if (!enableDynamicTheme) customThemeSeedPalette else null,
                disableAnimations = disableAnimations,
                fontPreference = fontPreference,
                customFontUri = customFontUri,
            ) {
                    BoxWithConstraints(
                        modifier =
                        Modifier
                            .fillMaxSize()
                            .background(
                                if(pureBlack) Color.Black else MaterialTheme.colorScheme.surface
                            )
                    ) {
                    val focusManager = LocalFocusManager.current
                    val keyboardController = LocalSoftwareKeyboardController.current
                    val density = LocalDensity.current
                    val windowsInsets = WindowInsets.systemBars
                    val topInset = with(density) { windowsInsets.getTop(density).toDp() }
                    val bottomInset = with(density) { windowsInsets.getBottom(density).toDp() }
                    val bottomInsetDp = WindowInsets.systemBars.asPaddingValues().calculateBottomPadding()
                        
                    val isTvDevice = remember { applicationContext.isTvDevice() }
                    val useRail = isTvDevice || currentWindowAdaptiveInfo().windowSizeClass
                        .isWidthAtLeastBreakpoint(WindowSizeClass.WIDTH_DP_MEDIUM_LOWER_BOUND)

                    val navController = rememberNavController()
                    val coroutineScope = rememberCoroutineScope()
                    val homeViewModel: HomeViewModel = hiltViewModel()
                    val networkBannerViewModel: NetworkBannerViewModel = hiltViewModel()
                    val allLocalItems by homeViewModel.allLocalItems.collectAsState()
                    val allYtItems by homeViewModel.allYtItems.collectAsState()
                    val networkBannerState by networkBannerViewModel.bannerState.collectAsStateWithLifecycle()
                    val navBackStackEntry by navController.currentBackStackEntryAsState()
                    val (previousTab) = rememberSaveable { mutableStateOf("home") }
                    val currentRoute = navBackStackEntry?.destination?.route
                    val isYearInMusicScreen = currentRoute?.startsWith("year_in_music") == true

                    val navigationItems = remember(isTvDevice) {
                        if (isTvDevice) Screens.TvMainScreens else Screens.MainScreens
                    }
                    val (savedMiniPlayerAnchor, setSavedMiniPlayerAnchor) = rememberPreference(
                        MiniPlayerLastAnchorKey,
                        defaultValue = COLLAPSED_ANCHOR
                    )
                    val defaultOpenTab by rememberEnumPreference(DefaultOpenTabKey, NavigationTab.HOME)
                    val pauseSearchHistory by rememberPreference(PauseSearchHistoryKey, defaultValue = false)
                    val tabOpenedFromShortcut =
                        remember {
                            when (intent?.action) {
                                ACTION_LIBRARY -> NavigationTab.LIBRARY
                                ACTION_SEARCH -> NavigationTab.SEARCH
                                else -> null
                            }
                        }
                    val launchMusicRecognitionFromShortcut =
                        remember {
                            intent?.action == ACTION_MUSIC_RECOGNITION
                        }

                    val onboardingCompleted = remember {
                        PreferenceStore.get(PixelMusicOnboardingCompletedKey) ?: false
                    }


                    val topLevelScreens = remember(navigationItems) {
                        navigationItems.map(Screens::route) + "settings"
                    }

                    val (query, onQueryChange) =
                        rememberSaveable(stateSaver = TextFieldValue.Saver) {
                            mutableStateOf(TextFieldValue())
                        }

                    var active by rememberSaveable {
                        mutableStateOf(false)
                    }

                    var lastTopLevelRoute by rememberSaveable { mutableStateOf(Screens.Home.route) }
                    LaunchedEffect(currentRoute) {
                        if (currentRoute != null && navigationItems.fastAny { it.route == currentRoute }) {
                            lastTopLevelRoute = currentRoute
                        }
                    }

                    var greetingAnimationFinished by rememberSaveable { mutableStateOf(false) }
                    val greeting = stringResource(getGreetingResId())
                    val musicTitle = stringResource(R.string.app_name)
                    var currentHomeTitle by rememberSaveable { 
                        mutableStateOf(if (greetingAnimationFinished) musicTitle else "") 
                    }

                    LaunchedEffect(Unit) {
                        if (!greetingAnimationFinished) {
                            delay(500)
                            currentHomeTitle = greeting
                            delay(2500)
                            currentHomeTitle = ""
                            delay(500)
                            currentHomeTitle = musicTitle
                            greetingAnimationFinished = true
                        } else {
                            currentHomeTitle = musicTitle
                        }
                    }

                    val onActiveChange: (Boolean) -> Unit = { newActive ->
                        active = newActive
                        if (!newActive) {
                            focusManager.clearFocus()
                            if (navigationItems.fastAny { it.route == navBackStackEntry?.destination?.route }) {
                                onQueryChange(TextFieldValue())
                            }
                        }
                    }

                    var searchSource by rememberEnumPreference(SearchSourceKey, SearchSource.ONLINE)

                    val searchBarFocusRequester = remember { FocusRequester() }
                    val tvRailFocusRequester = remember { FocusRequester() }
                    val contentAreaFocusRequester = remember { FocusRequester() }

                    val openSearch: () -> Unit = {
                        navController.navigate(Screens.Search.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }

                    val onSearch: (String) -> Unit = {
                        if (it.isNotEmpty()) {
                            onActiveChange(false)
                            navController.navigate(onlineSearchResultRoute(it))
                            if (!pauseSearchHistory) {
                                database.query {
                                    insert(SearchHistory(query = it))
                                }
                            }
                        }
                    }

                    var openSearchImmediately: Boolean by remember {
                        mutableStateOf(intent?.action == ACTION_SEARCH)
                    }

                    val shouldShowSearchBar =
                        remember(active, navBackStackEntry) {
                            active ||
                                    navigationItems.fastAny { it.route == navBackStackEntry?.destination?.route } ||
                                    navBackStackEntry?.destination?.route?.startsWith(OnlineSearchResultRoutePrefix) == true
                        }

                    val shouldShowNavigationBar =
                        remember(navBackStackEntry, active) {
                            navBackStackEntry?.destination?.route == null ||
                                    navigationItems.fastAny { it.route == navBackStackEntry?.destination?.route } &&
                                    !active
                        }

                    val shouldShowHomeShuffleButton =
                        currentRoute == Screens.Home.route &&
                            (allLocalItems.isNotEmpty() || allYtItems.isNotEmpty())

                    fun getBottomNavPadding(): Dp {
                        return if (shouldShowNavigationBar && !useRail) {
                            FloatingToolbarHeight
                        } else {
                            0.dp
                        }
                    }

                    val floatingBarsBottomPadding = FloatingToolbarBottomPadding
                    val navVisibleHeight = FloatingToolbarHeight

                    val bottomNavigationBarHeight by animateDpAsState(
                        targetValue = if (shouldShowNavigationBar && !useRail) navVisibleHeight else 0.dp,
                        animationSpec = if (disableAnimations) snap() else NavigationBarAnimationSpec,
                        label = "",
                    )

                    val playerBottomSheetState =
                        rememberBottomSheetState(
                            dismissedBound = 0.dp,
                            collapsedBound =
                                bottomInset +
                                    (if (shouldShowNavigationBar && !useRail) floatingBarsBottomPadding else 0.dp) +
                                    getBottomNavPadding() +
                                    MiniPlayerBottomSpacing +
                                    MiniPlayerHeight,
                            expandedBound = maxHeight,
                        )

                    val playerBackground by rememberEnumPreference(
                        key = PlayerBackgroundStyleKey,
                        defaultValue = PlayerBackgroundStyle.DEFAULT,
                    )
                    val playerDesignStyle by rememberEnumPreference(
                        key = PlayerDesignStyleKey,
                        defaultValue = PlayerDesignStyle.V4,
                    )

                    val aodModeEnabled by remember(playerConnection) {
                        playerConnection?.aodModeEnabled ?: MutableStateFlow(false)
                    }.collectAsStateWithLifecycle()

                    LaunchedEffect(aodModeEnabled) {
                        val controller = WindowCompat.getInsetsController(window, window.decorView)
                        if (aodModeEnabled) {
                            controller.systemBarsBehavior =
                                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                            controller.hide(WindowInsetsCompat.Type.systemBars())
                            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        } else {
                            controller.show(WindowInsetsCompat.Type.systemBars())
                            controller.systemBarsBehavior =
                                WindowInsetsControllerCompat.BEHAVIOR_DEFAULT
                            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        }
                    }

                    val isPlayerFullscreen by remember {
                        derivedStateOf {
                            playerBottomSheetState.isExpanded || playerBottomSheetState.progress >= 0.5f
                        }
                    }

                    val systemBarsFadeAlpha by animateFloatAsState(
                        targetValue = if (isPlayerFullscreen) 1f else 0f,
                        animationSpec = tween(durationMillis = 300),
                        label = "systemBarsFadeAlpha",
                    )

                    LaunchedEffect(useDarkTheme, isPlayerFullscreen, aodModeEnabled) {
                        if (aodModeEnabled) return@LaunchedEffect
                        val isDarkStatusBar = if (isPlayerFullscreen) {
                            true
                        } else {
                            useDarkTheme
                        }
                        setSystemBarAppearance(isDarkStatusBar)
                    }

                    val miniPlayerAnchor by remember {
                        derivedStateOf {
                            when {
                                playerBottomSheetState.isExpanded -> EXPANDED_ANCHOR
                                playerBottomSheetState.isDismissed -> DISMISSED_ANCHOR
                                else -> COLLAPSED_ANCHOR
                            }
                        }
                    }

                    var miniPlayerAnchorPersistenceEnabled by remember(playerConnection) {
                        mutableStateOf(false)
                    }

                    LaunchedEffect(miniPlayerAnchor, isYearInMusicScreen, miniPlayerAnchorPersistenceEnabled) {
                        if (!isYearInMusicScreen && miniPlayerAnchorPersistenceEnabled) {
                            setSavedMiniPlayerAnchor(miniPlayerAnchor)
                        }
                        }

                    var yearInMusicSavedPlayerAnchor by rememberSaveable { mutableStateOf(-1) }

                    val shouldHideStatusBars =
                        isYearInMusicScreen ||
                            (playerBottomSheetState.isExpanded && playerDesignStyle == PlayerDesignStyle.V7)

                    LaunchedEffect(shouldHideStatusBars, aodModeEnabled) {
                        if (aodModeEnabled) return@LaunchedEffect
                        val controller = WindowCompat.getInsetsController(window, window.decorView)
                        if (shouldHideStatusBars) {
                            controller.systemBarsBehavior =
                                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                            controller.hide(WindowInsetsCompat.Type.statusBars())
                        } else {
                            controller.show(WindowInsetsCompat.Type.statusBars())
                        }
                    }

                    LaunchedEffect(isYearInMusicScreen, playerConnection) {
                        val connection = playerConnection ?: return@LaunchedEffect
                        val player = connection.player

                        if (isYearInMusicScreen) {
                            if (yearInMusicSavedPlayerAnchor == -1) {
                                yearInMusicSavedPlayerAnchor =
                                    when {
                                        playerBottomSheetState.isExpanded -> EXPANDED_ANCHOR
                                        playerBottomSheetState.isCollapsed -> COLLAPSED_ANCHOR
                                        playerBottomSheetState.isDismissed -> DISMISSED_ANCHOR
                                        else -> COLLAPSED_ANCHOR
                                    }
                            }

                            if (!playerBottomSheetState.isDismissed) {
                                playerBottomSheetState.dismiss()
                            }
                        } else if (yearInMusicSavedPlayerAnchor != -1) {
                            val anchorToRestore = yearInMusicSavedPlayerAnchor
                            yearInMusicSavedPlayerAnchor = -1

                            if (!awaitRestorablePlayback(connection)) {
                                playerBottomSheetState.dismiss()
                            } else {
                                when (anchorToRestore) {
                                    EXPANDED_ANCHOR -> playerBottomSheetState.expandSoft()
                                    COLLAPSED_ANCHOR -> playerBottomSheetState.collapseSoft()
                                    DISMISSED_ANCHOR -> playerBottomSheetState.collapseSoft()
                                    else -> playerBottomSheetState.collapseSoft()
                                }
                            }
                        }
                    }

                    val playerAwareWindowInsets =
                        remember(
                            useRail,
                            bottomInset,
                            shouldShowNavigationBar,
                            playerBottomSheetState.isDismissed,
                        ) {
                            var bottom = bottomInset
                            if (shouldShowNavigationBar && !useRail) {
                                bottom += getBottomNavPadding() + floatingBarsBottomPadding
                            }
                            if (!playerBottomSheetState.isDismissed) {
                                bottom += MiniPlayerHeight + MiniPlayerBottomSpacing
                            }
                            windowsInsets
                                .only((if(useRail) {
                                    WindowInsetsSides.Right
                                } else WindowInsetsSides.Horizontal) + WindowInsetsSides.Top)
                                .add(WindowInsets(top = AppBarHeight, bottom = bottom))
                        }

                    appBarScrollBehavior(
                        canScroll = {
                            navBackStackEntry?.destination?.route?.startsWith(OnlineSearchResultRoutePrefix) == false &&
                                    navBackStackEntry?.destination?.route != Screens.Home.route &&
                                    navBackStackEntry?.destination?.route != Screens.MoodAndGenres.route &&
                                    navBackStackEntry?.destination?.route != Screens.Library.route &&
                                    (playerBottomSheetState.isCollapsed || playerBottomSheetState.isDismissed)
                        }
                    )

                    val searchBarScrollBehavior =
                        appBarScrollBehavior(
                            canScroll = {
                                navBackStackEntry?.destination?.route?.startsWith(OnlineSearchResultRoutePrefix) == false &&
                                        navBackStackEntry?.destination?.route != Screens.Home.route &&
                                        navBackStackEntry?.destination?.route != Screens.MoodAndGenres.route &&
                                        navBackStackEntry?.destination?.route != Screens.Library.route &&
                                        (playerBottomSheetState.isCollapsed || playerBottomSheetState.isDismissed)
                            },
                        )
                    val topAppBarScrollBehavior =
                        appBarScrollBehavior(
                            canScroll = {
                                navBackStackEntry?.destination?.route?.startsWith(OnlineSearchResultRoutePrefix) == false &&
                                        navBackStackEntry?.destination?.route != Screens.Home.route &&
                                        navBackStackEntry?.destination?.route != Screens.MoodAndGenres.route &&
                                        navBackStackEntry?.destination?.route != Screens.Library.route &&
                                        (playerBottomSheetState.isCollapsed || playerBottomSheetState.isDismissed)
                            },
                        )

                    val handlePrimaryNavigationClick: (Screens, Boolean) -> Unit = { screen, isSelected ->
                        if (isSelected) {
                            if (screen == Screens.Search) {
                                if (currentRoute?.startsWith(OnlineSearchResultRoutePrefix) == true) {
                                    navController.navigate(Screens.Search.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                                onActiveChange(true)
                                coroutineScope.launch {
                                    searchBarScrollBehavior.state.resetHeightOffset()
                                    topAppBarScrollBehavior.state.resetHeightOffset()
                                    delay(100)
                                    searchBarFocusRequester.requestFocus()
                                    keyboardController?.show()
                                }
                            } else {
                                navController.currentBackStackEntry?.savedStateHandle?.set("scrollToTop", true)
                                coroutineScope.launch {
                                    searchBarScrollBehavior.state.resetHeightOffset()
                                }
                            }
                        } else {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    }

                    var previousRoute by rememberSaveable { mutableStateOf<String?>(null) }

                    LaunchedEffect(navBackStackEntry) {
                        val currentRoute = navBackStackEntry?.destination?.route
                        val wasOnNonTopLevelScreen = previousRoute != null &&
                            previousRoute !in topLevelScreens &&
                            previousRoute?.startsWith(OnlineSearchResultRoutePrefix) != true
                        val isReturningToHomeOrLibrary = currentRoute == Screens.Home.route ||
                            currentRoute == Screens.Library.route

                        if (wasOnNonTopLevelScreen && isReturningToHomeOrLibrary) {
                            searchBarScrollBehavior.state.resetHeightOffset()
                            topAppBarScrollBehavior.state.resetHeightOffset()
                        }

                        val isEnteringSubScreen = currentRoute != null &&
                            currentRoute !in topLevelScreens &&
                            currentRoute.startsWith(OnlineSearchResultRoutePrefix) != true
                        if (isEnteringSubScreen) {
                            topAppBarScrollBehavior.state.contentOffset = 0f
                        }

                        previousRoute = currentRoute

                        if ((currentRoute?.startsWith("artist/") == true ||
                                currentRoute?.startsWith("album/") == true) &&
                            playerBottomSheetState.isExpanded
                        ) {
                            playerBottomSheetState.collapseSoft()
                        }

                        if (navBackStackEntry?.destination?.route?.startsWith(OnlineSearchResultRoutePrefix) == true) {
                            val searchQuery = decodeOnlineSearchQuery(
                                navBackStackEntry
                                    ?.arguments
                                    ?.getString(OnlineSearchResultArgument)
                                    .orEmpty()
                            )
                            onQueryChange(
                                TextFieldValue(
                                    searchQuery,
                                    TextRange(searchQuery.length)
                                )
                            )
                        } else if (navigationItems.fastAny { it.route == navBackStackEntry?.destination?.route } || navBackStackEntry?.destination?.route in topLevelScreens) {
                            onQueryChange(TextFieldValue())
                            if (navBackStackEntry?.destination?.route != Screens.Home.route) {
                                searchBarScrollBehavior.state.resetHeightOffset()
                                topAppBarScrollBehavior.state.resetHeightOffset()
                            }
                        }
                    }
                    LaunchedEffect(active) {
                        if (active) {
                            searchBarScrollBehavior.state.resetHeightOffset()
                            topAppBarScrollBehavior.state.resetHeightOffset()
                            searchBarFocusRequester.requestFocus()
                        }
                    }

                    LaunchedEffect(isTvDevice, useRail, active, currentRoute, shouldShowNavigationBar) {
                        if (
                            isTvDevice &&
                            useRail &&
                            shouldShowNavigationBar &&
                            !active &&
                            currentRoute in topLevelScreens
                        ) {
                            delay(100)
                            tvRailFocusRequester.requestFocus()
                        }
                    }

                    var restoredMiniPlayerAnchor by remember(playerConnection) { mutableStateOf(false) }

                    LaunchedEffect(playerConnection, savedMiniPlayerAnchor, isYearInMusicScreen) {
                        if (restoredMiniPlayerAnchor) return@LaunchedEffect
                        val connection = playerConnection ?: return@LaunchedEffect
                        connection.queueRestoreCompleted.first { it }
                        if (!awaitRestorablePlayback(connection)) {
                            if (!playerBottomSheetState.isDismissed) {
                                playerBottomSheetState.dismiss()
                            }
                        } else {
                            if (!isYearInMusicScreen) {
                                when (savedMiniPlayerAnchor) {
                                    EXPANDED_ANCHOR -> playerBottomSheetState.expandSoft()
                                    COLLAPSED_ANCHOR -> playerBottomSheetState.collapseSoft()
                                    DISMISSED_ANCHOR -> playerBottomSheetState.collapseSoft()
                                    else -> playerBottomSheetState.collapseSoft()
                                }
                            }
                        }
                        restoredMiniPlayerAnchor = true
                        miniPlayerAnchorPersistenceEnabled = true
                    }

                    val currentPlayerBottomSheetState = rememberUpdatedState(playerBottomSheetState)
                    val currentIsYearInMusicScreen = rememberUpdatedState(isYearInMusicScreen)

                    DisposableEffect(playerConnection) {
                        val player =
                            playerConnection?.player ?: return@DisposableEffect onDispose { }
                        val listener =
                            object : Player.Listener {
                                private fun collapseDismissedMiniPlayerForActivePlayback() {
                                    if (
                                        player.mediaItemCount > 0 &&
                                        player.currentMediaItem != null &&
                                        player.playWhenReady &&
                                        player.playbackState != Player.STATE_IDLE &&
                                        player.playbackState != Player.STATE_ENDED &&
                                        currentPlayerBottomSheetState.value.isDismissed &&
                                        !currentIsYearInMusicScreen.value
                                    ) {
                                        currentPlayerBottomSheetState.value.collapseSoft()
                                    }
                                }

                                override fun onMediaItemTransition(
                                    mediaItem: MediaItem?,
                                    reason: Int,
                                ) {
                                    collapseDismissedMiniPlayerForActivePlayback()
                                }

                                override fun onTimelineChanged(
                                    timeline: Timeline,
                                    reason: Int,
                                ) {
                                    collapseDismissedMiniPlayerForActivePlayback()
                                }

                                override fun onPlaybackStateChanged(playbackState: Int) {
                                    collapseDismissedMiniPlayerForActivePlayback()
                                }

                                override fun onPlayWhenReadyChanged(
                                    playWhenReady: Boolean,
                                    reason: Int,
                                ) {
                                    collapseDismissedMiniPlayerForActivePlayback()
                                }
                            }
                        player.addListener(listener)
                        onDispose {
                            player.removeListener(listener)
                        }
                    }

                    var shouldShowTopBar by rememberSaveable { mutableStateOf(false) }
                    var isSettingsMenuOpen by rememberSaveable { mutableStateOf(false) }

                    val innerTubeCookie by rememberPreference(InnerTubeCookieKey, "")
                    val accountImageUrlPref by rememberPreference(AccountImageUrlKey, "")
                    val (isRecapBubbleDismissed, onRecapBubbleDismissedChange) = rememberPreference(RecapBubbleDismissedKey, false)
                    val disableBlur by rememberPreference(DisableBlurKey, false)

                    val isLoggedIn = remember(innerTubeCookie) {
                        hasYouTubeLoginCookie(innerTubeCookie)
                    }
                    val youtubeProfileUrl = remember(isLoggedIn, accountImageUrlPref) {
                        if (isLoggedIn && accountImageUrlPref.isNotBlank()) accountImageUrlPref else null
                    }

                    val isSecondHalfOfDecember = remember { isRecapTimePeriod() }

                    val isHomeScreen = navBackStackEntry?.destination?.route == Screens.Home.route

                    LaunchedEffect(isHomeScreen, isSecondHalfOfDecember, isRecapBubbleDismissed) {
                        if (isHomeScreen && isSecondHalfOfDecember && !isRecapBubbleDismissed) {
                            delay(5000L)
                            onRecapBubbleDismissedChange(true)
                        }
                    }

                    LaunchedEffect(navBackStackEntry) {
                        shouldShowTopBar =
                            !active && navBackStackEntry?.destination?.route in topLevelScreens && 
                            navBackStackEntry?.destination?.route != "settings"
                        
                        if (navBackStackEntry?.destination?.route in topLevelScreens) {
                            searchBarScrollBehavior.state.contentOffset = 0f
                            searchBarScrollBehavior.state.heightOffset = 0f
                            topAppBarScrollBehavior.state.contentOffset = 0f
                            topAppBarScrollBehavior.state.heightOffset = 0f
                        }
                    }

                    var sharedSong: SongItem? by remember {
                        mutableStateOf(null)
                    }

                    LaunchedEffect(Unit) {
                        if (pendingIntent != null) {
                            handleIntent(pendingIntent, navController)
                            pendingIntent = null
                        } else {
                            handleIntent(intent, navController)
                        }
                    }


                    var showCreatePlaylistDialog by rememberSaveable { mutableStateOf(false) }

                    val haptic = LocalHapticFeedback.current
                    val (enableHapticFeedback) = rememberPreference(EnableHapticFeedbackKey, true)
                    val customHaptic = remember(haptic, enableHapticFeedback) {
                        object : HapticFeedback {
                            override fun performHapticFeedback(hapticFeedbackType: HapticFeedbackType) {
                                if (enableHapticFeedback) {
                                    haptic.performHapticFeedback(hapticFeedbackType)
                                }
                            }
                        }
                    }

                    CompositionLocalProvider(
                        LocalHapticFeedback provides customHaptic,
                        LocalAnimationsDisabled provides disableAnimations,
                        LocalDatabase provides database,
                        LocalContentColor provides if (pureBlack) Color.White else contentColorFor(MaterialTheme.colorScheme.surface),
                        LocalPlayerConnection provides playerConnection,
                        LocalPlayerAwareWindowInsets provides playerAwareWindowInsets,
                        LocalDownloadUtil provides downloadUtil,
                        LocalShimmerTheme provides ShimmerTheme,
                        LocalSyncUtils provides syncUtils,
                        com.zlgskt6.pixelmusic.ui.component.LocalBottomSheetPageState provides bottomSheetPageState,
                        com.zlgskt6.pixelmusic.ui.component.LocalMenuState provides menuState,
                    ) {
                        if (showCreatePlaylistDialog) {
                            CreatePlaylistDialog(
                                onDismiss = { showCreatePlaylistDialog = false },
                            )
                        }

                        Row {
                            AnimatedVisibility(
                                visible = useRail && shouldShowNavigationBar,
                                enter = fadeIn(animationSpec = tween(durationMillis = if (disableAnimations) 0 else 150)),
                                exit = fadeOut(animationSpec = tween(durationMillis = if (disableAnimations) 0 else 100)),
                            ) {
                                if (isTvDevice) {
                                    TvNavigationRail(
                                        items = navigationItems,
                                        selectedItemRoute = currentRoute,
                                        modifier = Modifier,
                                        firstItemFocusRequester = tvRailFocusRequester,
                                        contentFocusRequester =
                                            if (active || navBackStackEntry?.destination?.route?.startsWith(OnlineSearchResultRoutePrefix) == true) {
                                                searchBarFocusRequester
                                            } else {
                                                contentAreaFocusRequester
                                            },
                                        onItemClick = { screen ->
                                            val wasPlayerActive = playerBottomSheetState.isExpanded
                                            if (wasPlayerActive) {
                                                playerBottomSheetState.collapse(if (disableAnimations) snap() else spring())
                                            }
                                            val isSelected =
                                                navBackStackEntry?.destination?.hierarchy?.any { it.route == screen.route } == true
                                            if (wasPlayerActive && isSelected) {
                                                return@TvNavigationRail
                                            }
                                            handlePrimaryNavigationClick(screen, isSelected)
                                        },
                                    )
                                } else {
                                    NavigationRail(
                                        containerColor = if(pureBlack) Color.Black else MaterialTheme.colorScheme.surfaceContainer,
                                        contentColor = if(pureBlack) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                        header = { Spacer(Modifier.height(24.dp)) }
                                    ) {
                                        navigationItems.fastForEach { screen ->
                                            val isSelected =
                                                navBackStackEntry?.destination?.hierarchy?.any { it.route == screen.route } == true

                                            NavigationRailItem(
                                                selected = isSelected,
                                                icon = {
                                                    Icon(
                                                        painter = painterResource(
                                                            id = if (isSelected) screen.iconIdActive else screen.iconIdInactive
                                                        ),
                                                        contentDescription = null,
                                                    )
                                                },
                                                label = {
                                                    Text(
                                                        text = stringResource(screen.titleId),
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                },
                                                onClick = {
                                                    val wasPlayerActive = playerBottomSheetState.isExpanded
                                                    
                                                    if(wasPlayerActive) {
                                                        playerBottomSheetState.collapse(if (disableAnimations) snap() else spring())
                                                    }
                                                    
                                                    if(wasPlayerActive && isSelected) return@NavigationRailItem
                                                    handlePrimaryNavigationClick(screen, isSelected)
                                                },
                                            )
                                        }
                                    }
                                }
                            }
                            
                            val playerProgress = playerBottomSheetState.progress.coerceIn(0f, 1f)
                            val bgScale = 1f - (playerProgress * 0.05f)
                            val bgBlurDp = (playerProgress * 12f).dp

                            val settingsMenuProgress by animateFloatAsState(
                                targetValue = if (isSettingsMenuOpen) 1f else 0f,
                                animationSpec = tween(durationMillis = 350, easing = FastOutSlowInEasing),
                                label = "settingsMenuProgress",
                            )
                            val effectiveBgScale = bgScale * (1f - (settingsMenuProgress * 0.04f))
                            val effectiveBgBlurDp = if (!disableBlur) (bgBlurDp + (settingsMenuProgress * 16f).dp) else 0.dp

                            Scaffold(
                                topBar = {
                                    if (shouldShowTopBar) {
                                        val shouldUseFloatingTopBar = remember(navBackStackEntry) {
                                            navBackStackEntry?.destination?.route == Screens.Home.route ||
                                                navBackStackEntry?.destination?.route == Screens.Search.route ||
                                                navBackStackEntry?.destination?.route == Screens.MoodAndGenres.route ||
                                                navBackStackEntry?.destination?.route == Screens.Library.route
                                        }
                                        val shouldShowBlurBackground = remember(navBackStackEntry) {
                                            shouldUseFloatingTopBar
                                        }

                                        val surfaceColor = MaterialTheme.colorScheme.surface
                                        val currentScrollBehavior = if (shouldUseFloatingTopBar) searchBarScrollBehavior else topAppBarScrollBehavior
                                        val isHomeRoute = navBackStackEntry?.destination?.route == Screens.Home.route
                                        val isSearchRoute = navBackStackEntry?.destination?.route == Screens.Search.route
                                        val isMoodAndGenresRoute = navBackStackEntry?.destination?.route == Screens.MoodAndGenres.route
                                        val isLibraryRoute = navBackStackEntry?.destination?.route == Screens.Library.route
                                        val isFrozenRoute = isHomeRoute || isSearchRoute || isMoodAndGenresRoute || isLibraryRoute

                                        val appBarHeightPx = with(LocalDensity.current) { AppBarHeight.toPx() }
                                        val topBarAlpha by remember(currentScrollBehavior.state.contentOffset, isHomeRoute, isMoodAndGenresRoute) {
                                            derivedStateOf {
                                                if (isHomeRoute || isMoodAndGenresRoute) {
                                                    (1f + currentScrollBehavior.state.contentOffset / appBarHeightPx).coerceIn(0f, 1f)
                                                } else {
                                                    1f
                                                }
                                            }
                                        }

                                        Box(
                                            modifier = Modifier
                                                .offset {
                                                    IntOffset(
                                                        x = 0,
                                                        y = if (isFrozenRoute) 0 else currentScrollBehavior.state.heightOffset.toInt()
                                                    )
                                                }
                                                .graphicsLayer {
                                                    scaleX = effectiveBgScale
                                                    scaleY = effectiveBgScale
                                                    transformOrigin = TransformOrigin(0.5f, 0.5f)
                                                }
                                                .then(
                                                    if (!disableBlur && effectiveBgBlurDp > 0.dp) Modifier.blur(effectiveBgBlurDp)
                                                    else Modifier
                                                )
                                        ) {
                                            // Gradient shadow background
                                            if (shouldShowBlurBackground) {
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .height(AppBarHeight + with(LocalDensity.current) {
                                                            WindowInsets.systemBars.getTop(LocalDensity.current).toDp()
                                                        })
                                                        .background(
                                                            Brush.verticalGradient(
                                                                colors = listOf(
                                                                    surfaceColor.copy(alpha = 0.95f),
                                                                    surfaceColor.copy(alpha = 0.85f),
                                                                    surfaceColor.copy(alpha = 0.6f),
                                                                    Color.Transparent
                                                                )
                                                            )
                                                        )
                                                )
                                            }

                                            Box(
                                                modifier = Modifier
                                                    .graphicsLayer {
                                                        alpha = topBarAlpha
                                                    }
                                                    .offset {
                                                        IntOffset(x = 0, y = 0)
                                                    }
                                            ) {
                                                TopAppBar(
                                                    windowInsets = WindowInsets.safeDrawing.only((if(useRail) {
                                                        WindowInsetsSides.Right
                                                    } else WindowInsetsSides.Horizontal) + WindowInsetsSides.Top),
                                                    title = {
                                                        val route = navBackStackEntry?.destination?.route
                                                        val title = when (route) {
                                                            Screens.Home.route -> currentHomeTitle
                                                            Screens.Library.route -> stringResource(R.string.filter_library)
                                                            Screens.Search.route -> stringResource(R.string.search)
                                                            Screens.MoodAndGenres.route -> stringResource(R.string.explore)
                                                            else -> ""
                                                        }

                                                        Crossfade(targetState = title, label = "titleFade") { targetTitle ->
                                                            if (targetTitle.isNotEmpty()) {
                                                                Text(
                                                                    text = targetTitle,
                                                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                                                    maxLines = 1,
                                                                    overflow = TextOverflow.Ellipsis
                                                                )
                                                            }
                                                        }
                                                    },
                                                    actions = {
                                                        AnimatedVisibility(
                                                            visible = isHomeScreen && isSecondHalfOfDecember,
                                                            enter = fadeIn(tween(200)),
                                                            exit = fadeOut(tween(200))
                                                        ) {
                                                            IconButton(
                                                                onClick = {
                                                                    onRecapBubbleDismissedChange(true)
                                                                    navController.navigate("year_in_music")
                                                                },
                                                                modifier = Modifier.padding(end = 2.dp)
                                                            ) {
                                                                Icon(
                                                                    painter = painterResource(R.drawable.auto_awesome),
                                                                    contentDescription = stringResource(R.string.year_in_music),
                                                                    modifier = Modifier.size(24.dp),
                                                                    tint = MaterialTheme.colorScheme.primary
                                                                )
                                                            }
                                                        }

                                                        IconButton(
                                                            onClick = {
                                                                if (playerBottomSheetState.isExpanded) {
                                                                    playerBottomSheetState.collapseSoft()
                                                                }
                                                                isSettingsMenuOpen = true
                                                            },
                                                            modifier = Modifier.padding(end = 4.dp)
                                                        ) {
                                                            if (isLoggedIn && !youtubeProfileUrl.isNullOrBlank()) {
                                                                AsyncImage(
                                                                    model = youtubeProfileUrl,
                                                                    contentDescription = stringResource(R.string.account),
                                                                    modifier = Modifier
                                                                        .size(30.dp)
                                                                        .clip(CircleShape),
                                                                    contentScale = ContentScale.Crop,
                                                                )
                                                            } else {
                                                                Icon(
                                                                    painter = painterResource(R.drawable.account),
                                                                    contentDescription = stringResource(R.string.account),
                                                                    modifier = Modifier.size(26.dp),
                                                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                                )
                                                            }
                                                        }
                                                    },
                                                    scrollBehavior = if (isFrozenRoute) null else if (shouldUseFloatingTopBar) searchBarScrollBehavior else topAppBarScrollBehavior,
                                                    colors = TopAppBarDefaults.topAppBarColors(
                                                        containerColor = if (shouldUseFloatingTopBar) Color.Transparent else if (pureBlack) Color.Black else MaterialTheme.colorScheme.surface,
                                                        scrolledContainerColor = if (shouldUseFloatingTopBar) Color.Transparent else if (pureBlack) Color.Black else MaterialTheme.colorScheme.surface,
                                                        titleContentColor = MaterialTheme.colorScheme.onSurface,
                                                        actionIconContentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        navigationIconContentColor = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                )

                                                androidx.compose.animation.AnimatedVisibility(
                                                    visible = isHomeScreen && isSecondHalfOfDecember && !isRecapBubbleDismissed,
                                                    enter = fadeIn(tween(300)) + expandVertically(tween(300)),
                                                    exit = fadeOut(tween(300)) + shrinkVertically(tween(300)),
                                                    modifier = Modifier
                                                        .align(Alignment.TopEnd)
                                                        .padding(
                                                            top = AppBarHeight + with(LocalDensity.current) {
                                                                WindowInsets.systemBars.getTop(LocalDensity.current).toDp()
                                                            } - 6.dp,
                                                            end = 40.dp
                                                        )
                                                ) {
                                                    RecapReadyBubble(
                                                        onClick = {
                                                            onRecapBubbleDismissedChange(true)
                                                            navController.navigate("year_in_music")
                                                        }
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    AnimatedVisibility(
                                        visible = active || navBackStackEntry?.destination?.route?.startsWith(OnlineSearchResultRoutePrefix) == true,
                                        enter = fadeIn(animationSpec = tween(durationMillis = if (disableAnimations) 0 else 300)),
                                        exit = fadeOut(animationSpec = tween(durationMillis = if (disableAnimations) 0 else 200))
                                    ) {
                                        TopSearch(
                                            query = query,
                                            onQueryChange = onQueryChange,
                                            onSearch = onSearch,
                                            active = active,
                                            onActiveChange = onActiveChange,
                                            placeholder = {
                                                Text(
                                                    text = stringResource(
                                                        when (searchSource) {
                                                            SearchSource.LOCAL -> R.string.search_library
                                                            SearchSource.ONLINE -> R.string.search_yt_music
                                                        }
                                                    ),
                                                )
                                            },
                                            leadingIcon = {
                                                IconButton(
                                                    onClick = {
                                                        when {
                                                            active -> onActiveChange(false)
                                                            !navigationItems.fastAny { it.route == navBackStackEntry?.destination?.route } -> {
                                                                navController.navigateUp()
                                                            }

                                                            else -> onActiveChange(true)
                                                        }
                                                    },
                                                    onLongClick = {
                                                        when {
                                                            active -> {}
                                                            !navigationItems.fastAny { it.route == navBackStackEntry?.destination?.route } -> {
                                                                navController.backToMain()
                                                            }
                                                            else -> {}
                                                        }
                                                    },
                                                ) {
                                                    Icon(
                                                        painterResource(
                                                            if (active ||
                                                                !navigationItems.fastAny { it.route == navBackStackEntry?.destination?.route }
                                                            ) {
                                                                R.drawable.arrow_back
                                                            } else {
                                                                R.drawable.search
                                                            },
                                                        ),
                                                        contentDescription = null,
                                                    )
                                                }
                                            },
                                            trailingIcon = {
                                                Row {
                                                    if (active) {
                                                        if (query.text.isNotEmpty()) {
                                                            IconButton(
                                                                onClick = {
                                                                    onQueryChange(
                                                                        TextFieldValue(
                                                                            ""
                                                                        )
                                                                    )
                                                                },
                                                            ) {
                                                                Icon(
                                                                    painter = painterResource(R.drawable.close),
                                                                    contentDescription = null,
                                                                )
                                                            }
                                                        }
                                                        IconButton(
                                                            onClick = {
                                                                searchSource =
                                                                    if (searchSource == SearchSource.ONLINE) SearchSource.LOCAL else SearchSource.ONLINE
                                                            },
                                                        ) {
                                                            Icon(
                                                                painter = painterResource(
                                                                    when (searchSource) {
                                                                        SearchSource.LOCAL -> R.drawable.library_music
                                                                        SearchSource.ONLINE -> R.drawable.language
                                                                    },
                                                                ),
                                                                contentDescription = null,
                                                            )
                                                        }
                                                    }
                                                }
                                            },
                                            modifier =
                                                Modifier
                                                    .focusRequester(searchBarFocusRequester)
                                                    .let { with(this@BoxWithConstraints) { it.align(Alignment.TopCenter) } },
                                            focusRequester = searchBarFocusRequester,
                                            leftFocusRequester = tvRailFocusRequester,
                                            colors = if (pureBlack && active) {
                                                SearchBarDefaults.colors(
                                                    containerColor = Color.Black,
                                                    dividerColor = Color.DarkGray,
                                                    inputFieldColors = TextFieldDefaults.colors(
                                                        focusedTextColor = Color.White,
                                                        unfocusedTextColor = Color.Gray,
                                                        focusedContainerColor = Color.Transparent,
                                                        unfocusedContainerColor = Color.Transparent,
                                                        cursorColor = Color.White,
                                                        focusedIndicatorColor = Color.Transparent,
                                                        unfocusedIndicatorColor = Color.Transparent,
                                                    )
                                                )
                                            } else {
                                                SearchBarDefaults.colors(
                                                    containerColor = MaterialTheme.colorScheme.surfaceContainerLow
                                                )
                                            }
                                        ) {
                                            Crossfade(
                                                targetState = searchSource,
                                                animationSpec = tween(durationMillis = if (disableAnimations) 0 else 300),
                                                label = "",
                                                modifier =
                                                    Modifier
                                                        .fillMaxSize()
                                                        .padding(bottom = if(!playerBottomSheetState.isDismissed) MiniPlayerHeight else 0.dp)
                                                        .navigationBarsPadding(),
                                            ) { searchSource ->
                                                when (searchSource) {
                                                    SearchSource.LOCAL ->
                                                        LocalSearchScreen(
                                                            query = query.text,
                                                            navController = navController,
                                                            onDismiss = { onActiveChange(false) },
                                                            pureBlack = pureBlack,
                                                        )

                                                    SearchSource.ONLINE ->
                                                        OnlineSearchScreen(
                                                            query = query.text,
                                                            onQueryChange = onQueryChange,
                                                            navController = navController,
                                                            onSearch = {
                                                                navController.navigate(onlineSearchResultRoute(it))
                                                                if (!pauseSearchHistory) {
                                                                    database.query {
                                                                        insert(SearchHistory(query = it))
                                                                    }
                                                                }
                                                            },
                                                            onDismiss = { onActiveChange(false) },
                                                            pureBlack = pureBlack
                                                        )
                                                }
                                            }
                                        }
                                    }
                                },
                                bottomBar = {
                                    Box {
                                        BottomSheetPlayer(
                                            state = playerBottomSheetState,
                                            navController = navController,
                                            pureBlack = pureBlack
                                        )

                                        if(useRail) return@Box

                        val navSlideDistance =
                            bottomInset + floatingBarsBottomPadding + navVisibleHeight

                        Box(
                            modifier =
                                Modifier
                                    .align(Alignment.BottomCenter)
                                    .height(navSlideDistance)
                                    .offset {
                                        if (bottomNavigationBarHeight == 0.dp) {
                                            IntOffset(
                                                x = 0,
                                                y = navSlideDistance.roundToPx(),
                                            )
                                        } else {
                                            val slideOffset =
                                                navSlideDistance *
                                                    playerBottomSheetState.progress.coerceIn(
                                                        0f,
                                                        1f,
                                                    )
                                            val hideOffset =
                                                navSlideDistance *
                                                    (1 - bottomNavigationBarHeight.coerceAtMost(navVisibleHeight) / navVisibleHeight)
                                            IntOffset(
                                                x = 0,
                                                y = (slideOffset + hideOffset).roundToPx(),
                                            )
                                        }
                                    }
                                    .graphicsLayer {
                                        scaleX = effectiveBgScale
                                        scaleY = effectiveBgScale
                                        transformOrigin = TransformOrigin(0.5f, 0.5f)
                                    }
                                    .then(
                                        if (!disableBlur && effectiveBgBlurDp > 0.dp) Modifier.blur(effectiveBgBlurDp)
                                        else Modifier
                                    ),
                        ) {
                                            FloatingNavigationToolbar(
                                                items = navigationItems,
                                                pureBlack = pureBlack,
                                                modifier = Modifier
                                                    .align(Alignment.BottomCenter)
                                                    .padding(
                                                        start = FloatingToolbarHorizontalPadding,
                                                        end = FloatingToolbarHorizontalPadding,
                                                        bottom = bottomInset + floatingBarsBottomPadding,
                                                    )
                                                    .height(navVisibleHeight),
                                                onFabClick = {
                                                    if (playerBottomSheetState.isExpanded) {
                                                        playerBottomSheetState.collapseSoft()
                                                    }
                                                    isSettingsMenuOpen = true
                                                },
                                                fabIconRes = R.drawable.settings,
                                                fabContentDescription = stringResource(R.string.settings),
                                                onShuffleClick = if (shouldShowHomeShuffleButton) {
                                                    {
                                                        val useLocalSource = when {
                                                            allLocalItems.isNotEmpty() && allYtItems.isNotEmpty() -> Random.nextFloat() < 0.5f
                                                            allLocalItems.isNotEmpty() -> true
                                                            else -> false
                                                        }

                                                        coroutineScope.launch(Dispatchers.Main) {
                                                            if (useLocalSource) {
                                                                when (val luckyItem = allLocalItems.random()) {
                                                                    is Song -> {
                                                                        playerConnection?.playQueue(
                                                                            YouTubeQueue.radio(luckyItem.toMediaMetadata())
                                                                        )
                                                                    }

                                                                    is Album -> {
                                                                        val albumWithSongs = withContext(Dispatchers.IO) {
                                                                            database.albumWithSongs(luckyItem.id).first()
                                                                        }

                                                                        albumWithSongs?.let {
                                                                            playerConnection?.playQueue(LocalAlbumRadio(it))
                                                                        }
                                                                    }

                                                                    is Artist -> Unit
                                                                    is Playlist -> Unit
                                                                }
                                                            } else {
                                                                when (val luckyItem = allYtItems.random()) {
                                                                    is SongItem -> {
                                                                        playerConnection?.playQueue(
                                                                            YouTubeQueue.radio(luckyItem.toMediaMetadata())
                                                                        )
                                                                    }

                                                                    is AlbumItem -> {
                                                                        playerConnection?.playQueue(
                                                                            YouTubeAlbumRadio(luckyItem.playlistId)
                                                                        )
                                                                    }

                                                                    is ArtistItem -> {
                                                                        luckyItem.radioEndpoint?.let {
                                                                            playerConnection?.playQueue(YouTubeQueue(it))
                                                                        }
                                                                    }

                                                                    is PlaylistItem -> {
                                                                        luckyItem.playEndpoint?.let {
                                                                            playerConnection?.playQueue(YouTubeQueue.playlist(it))
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                } else null,
                                                shuffleIconRes = if (shouldShowHomeShuffleButton) R.drawable.shuffle else null,
                                                shuffleContentDescription = if (shouldShowHomeShuffleButton) stringResource(R.string.shuffle) else "",
                                                onMusicRecognitionClick = if (shouldShowHomeShuffleButton) {
                                                    { navController.navigate(MusicRecognitionRoute) }
                                                } else null,
                                                musicRecognitionContentDescription = if (shouldShowHomeShuffleButton) stringResource(R.string.music_recognition) else "",
                                                isSelected = { screen ->
                                                    screen.route == lastTopLevelRoute
                                                },
                                                onItemClick = { screen, isSelected ->
                                                    handlePrimaryNavigationClick(screen, isSelected)
                                                },
                                            )
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxSize()
                                    .nestedScroll(searchBarScrollBehavior.nestedScrollConnection)
                            ) {
                                NavHost(
                                    navController = navController,
                                    startDestination = when {
                                        launchMusicRecognitionFromShortcut -> MusicRecognitionRoute
                                        !onboardingCompleted -> "welcome"
                                        else -> when (tabOpenedFromShortcut ?: defaultOpenTab) {
                                            NavigationTab.HOME -> Screens.Home.route
                                            NavigationTab.SEARCH -> Screens.Search.route
                                            NavigationTab.MOODANDGENRES -> Screens.MoodAndGenres.route
                                            NavigationTab.LIBRARY -> Screens.Library.route
                                            else -> Screens.Home.route
                                        }
                                    },
                                    enterTransition = {
                                        val fromRoute = initialState.destination.route
                                        val toRoute = targetState.destination.route
                                        val fromMenuIndex = navigationItems.indexOfFirst { it.route == fromRoute }
                                        val toMenuIndex = navigationItems.indexOfFirst { it.route == toRoute }

                                        if (disableAnimations) {
                                            fadeIn(tween(0))
                                        } else if (fromMenuIndex != -1 && toMenuIndex != -1 && fromMenuIndex != toMenuIndex) {
                                            val isForward = toMenuIndex > fromMenuIndex
                                            slideInHorizontally(
                                                animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing),
                                                initialOffsetX = { fullWidth -> if (isForward) fullWidth else -fullWidth }
                                            ) + fadeIn(
                                                animationSpec = tween(durationMillis = 280, easing = FastOutSlowInEasing)
                                            )
                                        } else if (fromRoute in topLevelScreens && toRoute in topLevelScreens) {
                                            fadeIn(tween(250))
                                        } else {
                                            fadeIn(tween(250)) + slideInHorizontally { it / 2 }
                                        }
                                    },
                                    exitTransition = {
                                        val fromRoute = initialState.destination.route
                                        val toRoute = targetState.destination.route
                                        val fromMenuIndex = navigationItems.indexOfFirst { it.route == fromRoute }
                                        val toMenuIndex = navigationItems.indexOfFirst { it.route == toRoute }

                                        if (disableAnimations) {
                                            fadeOut(tween(0))
                                        } else if (fromMenuIndex != -1 && toMenuIndex != -1 && fromMenuIndex != toMenuIndex) {
                                            val isForward = toMenuIndex > fromMenuIndex
                                            slideOutHorizontally(
                                                animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing),
                                                targetOffsetX = { fullWidth -> if (isForward) -fullWidth else fullWidth }
                                            ) + fadeOut(
                                                animationSpec = tween(durationMillis = 240, easing = FastOutSlowInEasing)
                                            )
                                        } else if (fromRoute in topLevelScreens && toRoute in topLevelScreens) {
                                            fadeOut(tween(200))
                                        } else {
                                            fadeOut(tween(200)) + slideOutHorizontally { -it / 2 }
                                        }
                                    },
                                    popEnterTransition = {
                                        val fromRoute = initialState.destination.route
                                        val toRoute = targetState.destination.route
                                        val fromMenuIndex = navigationItems.indexOfFirst { it.route == fromRoute }
                                        val toMenuIndex = navigationItems.indexOfFirst { it.route == toRoute }

                                        if (disableAnimations) {
                                            fadeIn(tween(0))
                                        } else if (fromMenuIndex != -1 && toMenuIndex != -1 && fromMenuIndex != toMenuIndex) {
                                            val isForward = toMenuIndex > fromMenuIndex
                                            slideInHorizontally(
                                                animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing),
                                                initialOffsetX = { fullWidth -> if (isForward) fullWidth else -fullWidth }
                                            ) + fadeIn(
                                                animationSpec = tween(durationMillis = 280, easing = FastOutSlowInEasing)
                                            )
                                        } else if ((fromRoute in topLevelScreens || fromRoute?.startsWith(OnlineSearchResultRoutePrefix) == true) && toRoute in topLevelScreens) {
                                            fadeIn(tween(250))
                                        } else {
                                            fadeIn(tween(250)) + slideInHorizontally { -it / 2 }
                                        }
                                    },
                                    popExitTransition = {
                                        val fromRoute = initialState.destination.route
                                        val toRoute = targetState.destination.route
                                        val fromMenuIndex = navigationItems.indexOfFirst { it.route == fromRoute }
                                        val toMenuIndex = navigationItems.indexOfFirst { it.route == toRoute }

                                        if (disableAnimations) {
                                            fadeOut(tween(0))
                                        } else if (fromMenuIndex != -1 && toMenuIndex != -1 && fromMenuIndex != toMenuIndex) {
                                            val isForward = toMenuIndex > fromMenuIndex
                                            slideOutHorizontally(
                                                animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing),
                                                targetOffsetX = { fullWidth -> if (isForward) -fullWidth else fullWidth }
                                            ) + fadeOut(
                                                animationSpec = tween(durationMillis = 240, easing = FastOutSlowInEasing)
                                            )
                                        } else if ((fromRoute in topLevelScreens || fromRoute?.startsWith(OnlineSearchResultRoutePrefix) == true) && toRoute in topLevelScreens) {
                                            fadeOut(tween(200))
                                        } else {
                                            fadeOut(tween(200)) + slideOutHorizontally { it / 2 }
                                        }
                                    },
                                    modifier = Modifier
                                        .graphicsLayer {
                                            scaleX = effectiveBgScale
                                            scaleY = effectiveBgScale
                                            transformOrigin = TransformOrigin(0.5f, 0.5f)
                                        }
                                        .then(
                                            if (!disableBlur && effectiveBgBlurDp > 0.dp) Modifier.blur(effectiveBgBlurDp)
                                            else Modifier
                                        )
                                        .then(
                                            if (isTvDevice) Modifier
                                                .focusRequester(contentAreaFocusRequester)
                                                .focusGroup()
                                                .focusable()
                                            else Modifier
                                        )
                                        .nestedScroll(
                                            if (navigationItems.fastAny { it.route == navBackStackEntry?.destination?.route } ||
                                                navBackStackEntry?.destination?.route?.startsWith(OnlineSearchResultRoutePrefix) == true
                                            ) {
                                                searchBarScrollBehavior.nestedScrollConnection
                                            } else {
                                                topAppBarScrollBehavior.nestedScrollConnection
                                            }
                                        )
                                ) {
                                    navigationBuilder(
                                        navController,
                                        topAppBarScrollBehavior,
                                        { latestVersionName },
                                        disableAnimations,
                                        onClearUpdateBadge = { latestVersionName = BuildConfig.VERSION_NAME },
                                        homeViewModel = homeViewModel,
                                    )
                                }
                            }
                        }

                        BottomSheetMenu(
                            state = LocalMenuState.current,
                            modifier = Modifier.align(Alignment.BottomCenter)
                        )

                        BottomSheetPage(
                            state = LocalBottomSheetPageState.current,
                            modifier = Modifier.align(Alignment.BottomCenter)
                        )

                        SettingsBottomSheet(
                            isOpen = isSettingsMenuOpen,
                            onDismiss = { isSettingsMenuOpen = false },
                            navController = navController,
                            latestVersionName = latestVersionName,
                            onClearUpdateBadge = { latestVersionName = BuildConfig.VERSION_NAME },
                            modifier = Modifier.align(Alignment.BottomCenter)
                        )

                        sharedSong?.let { song ->
                            playerConnection?.let {
                                Dialog(
                                    onDismissRequest = { sharedSong = null },
                                    properties = DialogProperties(usePlatformDefaultWidth = false),
                                ) {
                                    Surface(
                                        modifier = Modifier.padding(24.dp),
                                        shape = RoundedCornerShape(16.dp),
                                        color = AlertDialogDefaults.containerColor,
                                        tonalElevation = AlertDialogDefaults.TonalElevation,
                                    ) {
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                        ) {
                                            YouTubeSongMenu(
                                                song = song,
                                                navController = navController,
                                                onDismiss = { sharedSong = null },
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        NetworkStatusBanner(
                            state = networkBannerState,
                            modifier =
                                Modifier
                                    .align(Alignment.TopCenter)
                                    .padding(
                                        top = if (shouldShowTopBar) topInset + AppBarHeight + 8.dp else topInset + 8.dp,
                                        start = 16.dp,
                                        end = 16.dp,
                                    )
                                    .zIndex(10f),
                        )

                        if (systemBarsFadeAlpha > 0f) {
                            Box(
                                modifier =
                                    Modifier
                                        .fillMaxWidth()
                                        .height(topInset)
                                        .align(Alignment.TopCenter)
                                        .graphicsLayer { alpha = systemBarsFadeAlpha }
                                        .background(
                                            Brush.verticalGradient(
                                                colors =
                                                    listOf(
                                                        Color.Black.copy(alpha = 0.45f),
                                                        Color.Transparent,
                                                    ),
                                            ),
                                        )
                                        .zIndex(6f),
                            )
                            Box(
                                modifier =
                                    Modifier
                                        .fillMaxWidth()
                                        .height(bottomInset)
                                        .align(Alignment.BottomCenter)
                                        .graphicsLayer { alpha = systemBarsFadeAlpha }
                                        .background(
                                            Brush.verticalGradient(
                                                colors =
                                                    listOf(
                                                        Color.Transparent,
                                                        Color.Black.copy(alpha = 0.35f),
                                                    ),
                                            ),
                                        )
                                        .zIndex(6f),
                            )
                        }
                    }

                    LaunchedEffect(shouldShowSearchBar, openSearchImmediately) {
                        if (shouldShowSearchBar && openSearchImmediately) {
                            onActiveChange(true)
                            try {
                                delay(100)
                                searchBarFocusRequester.requestFocus()
                            } catch (_: Exception) {
                            }
                            openSearchImmediately = false
                        }
                    }
                }
            }
        }
    }

    private fun handleIntent(intent: Intent?, navController: NavHostController) {
        if (intent == null) return
        if (intent.action == ACTION_MUSIC_RECOGNITION) {
            navController.openMusicRecognition()
            return
        }
        if (intent.action == "android.media.action.MEDIA_PLAY_FROM_SEARCH") {
            val query =
                (intent.getStringExtra("query")
                    ?: intent.getStringExtra("android.intent.extra.TITLE")
                    ?: "").trim()
            if (query.isNotBlank()) {
                pendingVoiceSearchQuery = query
                startMusicServiceSafely()
                playPendingVoiceSearchIfReady()
            }
            return
        }
        if (handleExternalAudioIntent(intent)) {
            return
        }
        handleDeepLinkIntent(intent, navController)
    }

    private fun handleExternalAudioIntent(intent: Intent): Boolean {
        val incomingUris = buildList {
            intent.data?.let(::add)
            when (intent.action) {
                Intent.ACTION_SEND -> {
                    IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)?.let(::add)
                }
                Intent.ACTION_SEND_MULTIPLE -> {
                    addAll(
                        IntentCompat.getParcelableArrayListExtra(
                            intent,
                            Intent.EXTRA_STREAM,
                            Uri::class.java
                        ).orEmpty()
                    )
                }
            }
        }.distinct()

        if (incomingUris.isEmpty()) return false

        val fallbackMimeType = intent.type
        val playableUris = incomingUris.filter { uri ->
            val mimeType = contentResolver.getType(uri)
            mimeType.isAudioMimeType() || fallbackMimeType.isAudioMimeType() || uri.hasAudioExtension()
        }
        if (playableUris.isEmpty()) return false

        pendingDeepLinkQueue = ListQueue(items = playableUris.map(::toExternalAudioMediaItem))
        startMusicServiceSafely()
        playPendingDeepLinkQueueIfReady()
        return true
    }

    private fun toExternalAudioMediaItem(uri: Uri): MediaItem {
        val mediaId = uri.toString()
        val title = resolveExternalAudioTitle(uri)
        val metadata =
            com.zlgskt6.pixelmusic.models.MediaMetadata(
                id = mediaId,
                title = title,
                artists = emptyList(),
                duration = -1,
            )
        return MediaItem.Builder()
            .setMediaId(mediaId)
            .setUri(uri)
            .setTag(metadata)
            .setMediaMetadata(
                androidx.media3.common.MediaMetadata.Builder()
                    .setTitle(title)
                    .setIsPlayable(true)
                    .setMediaType(MEDIA_TYPE_MUSIC)
                    .build()
            )
            .build()
    }

    private fun resolveExternalAudioTitle(uri: Uri): String {
        val displayName =
            runCatching {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    val columnIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (columnIndex >= 0 && cursor.moveToFirst()) cursor.getString(columnIndex) else null
                }
            }.getOrNull()
        return displayName
            ?.trim()
            ?.takeIf { it.isNotBlank() }
            ?: uri.lastPathSegment?.substringAfterLast('/')?.substringBefore('?')?.trim()?.takeIf { it.isNotBlank() }
            ?: getString(R.string.unknown)
    }

    private fun String?.isAudioMimeType(): Boolean =
        this?.startsWith("audio/", ignoreCase = true) == true

    private fun Uri.hasAudioExtension(): Boolean {
        val extension = MimeTypeMap.getFileExtensionFromUrl(toString()).orEmpty()
        val normalized = extension.lowercase(Locale.US)
        return normalized in setOf("aac", "flac", "m4a", "mp3", "ogg", "opus", "wav", "webm")
    }

    private fun handleDeepLinkIntent(intent: Intent, navController: NavHostController) {
        val uri = intent.data ?: intent.extras?.getString(Intent.EXTRA_TEXT)?.toUri() ?: return
        val coroutineScope = lifecycleScope

        val authority = uri.authority?.lowercase()
        if (uri.scheme.equals("pixelmusic", ignoreCase = true)) {
            when (authority) {
                "together" -> {
                    pendingTogetherJoinLink = uri.toString()
                    startMusicServiceSafely()
                    joinPendingTogetherIfReady()
                    return
                }
                "login" -> {
                    navController.navigate(buildLoginRoute(uri.getQueryParameter(LOGIN_URL_ARGUMENT)))
                    return
                }
                "search" -> {
                    navController.navigate(Screens.Search.route)
                    return
                }
                "library" -> {
                    navController.navigate(Screens.Library.route)
                    return
                }
                "music_recognition" -> {
                    navController.openMusicRecognition()
                    return
                }
            }
        }

        when (val path = uri.pathSegments.firstOrNull()) {
            "playlist" -> uri.getQueryParameter("list")?.let { playlistId ->
                if (playlistId.startsWith("OLAK5uy_")) {
                    coroutineScope.launch {
                        YouTube.albumSongs(playlistId).onSuccess { songs ->
                            songs.firstOrNull()?.album?.id?.let { browseId ->
                                navController.navigate("album/$browseId")
                            }
                        }.onFailure { reportException(it) }
                    }
                } else {
                    navController.navigate("online_playlist/$playlistId")
                }
            }

            "browse" -> uri.lastPathSegment?.let { browseId ->
                navController.navigate("album/$browseId")
            }

            "channel", "c" -> uri.lastPathSegment?.let { artistId ->
                navController.navigate("artist/$artistId")
            }

            else -> {
                val videoId = when {
                    path == "watch" -> uri.getQueryParameter("v")
                    uri.host == "youtu.be" -> uri.pathSegments.firstOrNull()
                    else -> null
                }
                val playlistId = uri.getQueryParameter("list")
                val shouldShufflePlaylist = uri.requestsShuffledPlayback()

                videoId?.let { vid ->
                    coroutineScope.launch {
                        val result = withContext(Dispatchers.IO) {
                            YouTube.queue(listOf(vid), playlistId)
                        }

                        result.onSuccess { queued ->
                            val mediaItem =
                                queued.firstOrNull { it.id == vid }?.toMediaItem()
                                    ?: queued.firstOrNull()?.toMediaItem()
                                    ?: MediaItem
                                        .Builder()
                                        .setMediaId(vid)
                                        .setUri(vid)
                                        .setCustomCacheKey(vid)
                                        .build()
                            pendingDeepLinkQueue = ListQueue(items = listOf(mediaItem))
                            startMusicServiceSafely()
                            playPendingDeepLinkQueueIfReady()
                        }.onFailure {
                            reportException(it)
                        }
                    }
                    return
                }

                if (path == "watch" && !playlistId.isNullOrBlank()) {
                    coroutineScope.launch {
                        val result = withContext(Dispatchers.IO) {
                            YouTube.playlist(playlistId)
                        }

                        result.onSuccess { playlistPage ->
                            val endpoint =
                                when {
                                    shouldShufflePlaylist -> playlistPage.playlist.shuffleEndpoint
                                        ?: playlistPage.playlist.playEndpoint
                                    else -> playlistPage.playlist.playEndpoint
                                        ?: playlistPage.playlist.shuffleEndpoint
                                }

                            endpoint?.let {
                                pendingDeepLinkQueue = YouTubeQueue.playlist(it)
                                startMusicServiceSafely()
                                playPendingDeepLinkQueueIfReady()
                            } ?: navController.navigate("online_playlist/$playlistId")
                        }.onFailure {
                            reportException(it)
                        }
                    }
                }
            }
        }
    }

    private fun android.net.Uri.requestsShuffledPlayback(): Boolean {
        val value = getQueryParameter("shuffle")?.trim()?.lowercase(Locale.US) ?: return false
        return value == "1" || value == "true"
    }

    private fun startMusicServiceSafely() {
        runCatching { startService(Intent(this, com.zlgskt6.pixelmusic.playback.MusicService::class.java)) }
            .onFailure { reportException(it) }
    }

    @SuppressLint("ObsoleteSdkInt")
    private fun setSystemBarAppearance(isDark: Boolean) {
        WindowCompat.getInsetsController(window, window.decorView.rootView).apply {
            isAppearanceLightStatusBars = !isDark
            isAppearanceLightNavigationBars = !isDark
        }
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = !isDark
            isAppearanceLightNavigationBars = !isDark
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            window.statusBarColor =
                (if (isDark) Color.Transparent else Color.Black.copy(alpha = 0.2f)).toArgb()
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            window.navigationBarColor =
                (if (isDark) Color.Transparent else Color.Black.copy(alpha = 0.2f)).toArgb()
        }
    }

    companion object {
        const val ACTION_SEARCH = "com.zlgskt6.pixelmusic.action.SEARCH"
        const val ACTION_LIBRARY = "com.zlgskt6.pixelmusic.action.LIBRARY"
    }
}

val LocalDatabase = staticCompositionLocalOf<MusicDatabase> { error("No database provided") }
val LocalPlayerConnection =
    staticCompositionLocalOf<PlayerConnection?> { error("No PlayerConnection provided") }
val LocalPlayerAwareWindowInsets =
    compositionLocalOf<WindowInsets> { error("No WindowInsets provided") }
val LocalDownloadUtil = staticCompositionLocalOf<DownloadUtil> { error("No DownloadUtil provided") }
val LocalSyncUtils = staticCompositionLocalOf<SyncUtils> { error("No SyncUtils provided") }

private fun Context.isTvDevice(): Boolean {
    val isTelevisionUiMode =
        (resources.configuration.uiMode and Configuration.UI_MODE_TYPE_MASK) ==
            Configuration.UI_MODE_TYPE_TELEVISION
    return isTelevisionUiMode ||
        packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK) ||
        packageManager.hasSystemFeature(PackageManager.FEATURE_TELEVISION)
}

@Composable
private fun RecapReadyBubble(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bubbleColor = MaterialTheme.colorScheme.primaryContainer
    val contentColor = MaterialTheme.colorScheme.onPrimaryContainer

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clickable(
                onClick = onClick,
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            )
    ) {
        Canvas(
            modifier = Modifier.size(width = 12.dp, height = 7.dp)
        ) {
            val path = Path().apply {
                moveTo(size.width / 2f, 0f)
                lineTo(size.width, size.height)
                lineTo(0f, size.height)
                close()
            }
            drawPath(path = path, color = bubbleColor)
        }

        Surface(
            shape = RoundedCornerShape(12.dp),
            color = bubbleColor,
            contentColor = contentColor,
            shadowElevation = 6.dp
        ) {
            Text(
                text = "Recap is ready!",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                maxLines = 1
            )
        }
    }
}
