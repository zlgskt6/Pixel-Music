/*
 * Pixel Music (2026)
 * © zlgskt6 — github.com/zlgskt6
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 *
 * Based on ArchiveTune (2026)
 * © Rukamori — github.com/rukamori
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package com.zlgskt6.pixelmusic.ui.screens.artist

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.view.WindowCompat
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Album
import androidx.compose.material.icons.outlined.Hearing
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.PersonAdd
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ButtonGroupDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.ToggleButton
import androidx.compose.material3.ToggleButtonDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.TopAppBarScrollBehavior
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.fastForEach
import androidx.compose.ui.zIndex
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import androidx.palette.graphics.Palette
import coil3.compose.AsyncImage
import coil3.imageLoader
import coil3.request.ImageRequest
import coil3.request.allowHardware
import coil3.size.Size
import coil3.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.zlgskt6.pixelmusic.LocalDatabase
import com.zlgskt6.pixelmusic.LocalPlayerAwareWindowInsets
import com.zlgskt6.pixelmusic.LocalPlayerConnection
import com.zlgskt6.pixelmusic.R
import com.zlgskt6.pixelmusic.constants.AppBarHeight
import com.zlgskt6.pixelmusic.constants.CONTENT_TYPE_ALBUM
import com.zlgskt6.pixelmusic.constants.CONTENT_TYPE_ARTIST
import com.zlgskt6.pixelmusic.constants.CONTENT_TYPE_HEADER
import com.zlgskt6.pixelmusic.constants.CONTENT_TYPE_LIST
import com.zlgskt6.pixelmusic.constants.CONTENT_TYPE_PLAYLIST
import com.zlgskt6.pixelmusic.constants.CONTENT_TYPE_SONG
import com.zlgskt6.pixelmusic.constants.DisableBlurKey
import com.zlgskt6.pixelmusic.constants.HideExplicitKey
import com.zlgskt6.pixelmusic.db.entities.ArtistEntity
import com.zlgskt6.pixelmusic.extensions.togglePlayPause
import com.zlgskt6.pixelmusic.extensions.toMediaItem
import com.zlgskt6.pixelmusic.innertube.models.AlbumItem
import com.zlgskt6.pixelmusic.innertube.models.ArtistItem
import com.zlgskt6.pixelmusic.innertube.models.BrowseEndpoint
import com.zlgskt6.pixelmusic.innertube.models.PlaylistItem
import com.zlgskt6.pixelmusic.innertube.models.SongItem
import com.zlgskt6.pixelmusic.innertube.models.WatchEndpoint
import com.zlgskt6.pixelmusic.innertube.pages.ArtistPage
import com.zlgskt6.pixelmusic.innertube.pages.ArtistSectionLayout
import com.zlgskt6.pixelmusic.models.toMediaMetadata
import com.zlgskt6.pixelmusic.playback.queues.ListQueue
import com.zlgskt6.pixelmusic.playback.queues.YouTubeQueue
import com.zlgskt6.pixelmusic.ui.component.AlbumGridItem
import com.zlgskt6.pixelmusic.ui.component.HideOnScrollFAB
import com.zlgskt6.pixelmusic.ui.component.IconButton
import com.zlgskt6.pixelmusic.ui.component.LocalMenuState
import com.zlgskt6.pixelmusic.ui.component.NavigationTitle
import com.zlgskt6.pixelmusic.ui.component.SongListItem
import com.zlgskt6.pixelmusic.ui.component.YouTubeGridItem
import com.zlgskt6.pixelmusic.ui.component.YouTubeListItem
import com.zlgskt6.pixelmusic.ui.component.shimmer.ButtonPlaceholder
import com.zlgskt6.pixelmusic.ui.component.shimmer.ListItemPlaceHolder
import com.zlgskt6.pixelmusic.ui.component.shimmer.ShimmerHost
import com.zlgskt6.pixelmusic.ui.component.shimmer.TextPlaceholder
import com.zlgskt6.pixelmusic.ui.menu.AlbumMenu
import com.zlgskt6.pixelmusic.ui.menu.SongMenu
import com.zlgskt6.pixelmusic.ui.menu.YouTubeAlbumMenu
import com.zlgskt6.pixelmusic.ui.menu.YouTubeArtistMenu
import com.zlgskt6.pixelmusic.ui.menu.YouTubePlaylistMenu
import com.zlgskt6.pixelmusic.ui.menu.YouTubeSongMenu
import com.zlgskt6.pixelmusic.ui.theme.PlayerColorExtractor
import com.zlgskt6.pixelmusic.ui.utils.backToMain
import com.zlgskt6.pixelmusic.ui.utils.formatCompactCount
import com.zlgskt6.pixelmusic.ui.utils.resize
import com.zlgskt6.pixelmusic.utils.rememberPreference
import com.zlgskt6.pixelmusic.viewmodels.ArtistViewModel
import com.valentinilk.shimmer.shimmer
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ArtistScreen(
    navController: NavController,
    scrollBehavior: TopAppBarScrollBehavior,
    viewModel: ArtistViewModel = hiltViewModel(),
) {
    val context = LocalContext.current
    val database = LocalDatabase.current
    val menuState = LocalMenuState.current
    val haptic = LocalHapticFeedback.current
    val coroutineScope = rememberCoroutineScope()
    val playerConnection = LocalPlayerConnection.current ?: return
    val isPlaying by playerConnection.isPlaying.collectAsStateWithLifecycle()
    val mediaMetadata by playerConnection.mediaMetadata.collectAsStateWithLifecycle()
    val artistPage = viewModel.artistPage
    val libraryArtist by viewModel.libraryArtist.collectAsStateWithLifecycle()
    val librarySongs by viewModel.librarySongs.collectAsStateWithLifecycle()
    val libraryAlbums by viewModel.libraryAlbums.collectAsStateWithLifecycle()
    val hideExplicit by rememberPreference(key = HideExplicitKey, defaultValue = false)
    val disableBlur by rememberPreference(key = DisableBlurKey, defaultValue = false)

    val lazyListState = rememberLazyListState()
    val snackbarHostState = remember { SnackbarHostState() }
    var showLocal by rememberSaveable { mutableStateOf(false) }
    val surfaceColor = MaterialTheme.colorScheme.surface

    // Get thumbnail URL
    val thumbnail = artistPage?.artist?.thumbnail ?: libraryArtist?.artist?.thumbnailUrl

    // Smooth zoom-out (from slightly zoomed in) and unblur animation for artist photo on enter
    var imageAnimationStarted by rememberSaveable(thumbnail) { mutableStateOf(false) }
    LaunchedEffect(thumbnail) {
        if (thumbnail != null) {
            imageAnimationStarted = true
        }
    }

    val photoScale by animateFloatAsState(
        targetValue = if (imageAnimationStarted) 1.0f else 1.15f,
        animationSpec = tween(
            durationMillis = 1100,
            easing = CubicBezierEasing(0.2f, 0.0f, 0.2f, 1.0f)
        ),
        label = "artist_photo_scale"
    )

    val photoBlurDp by animateFloatAsState(
        targetValue = if (!disableBlur && !imageAnimationStarted) 24f else 0f,
        animationSpec = tween(
            durationMillis = 1100,
            easing = CubicBezierEasing(0.2f, 0.0f, 0.2f, 1.0f)
        ),
        label = "artist_photo_blur"
    )

    // Image brightness detection for status bar & icon tint
    var isBrightImage by remember { mutableStateOf(false) }

    LaunchedEffect(thumbnail) {
        if (thumbnail != null) {
            val request = ImageRequest.Builder(context)
                .data(thumbnail)
                .size(Size(300, 300))
                .allowHardware(false)
                .build()

            val result = runCatching {
                context.imageLoader.execute(request)
            }.getOrNull()

            if (result != null) {
                val bitmap = result.image?.toBitmap()
                if (bitmap != null) {
                    isBrightImage = withContext(Dispatchers.Default) {
                        calculateTopLuminanceIsBright(bitmap)
                    }
                }
            }
        } else {
            isBrightImage = false
        }
    }

    val transparentAppBar by remember {
        derivedStateOf {
            lazyListState.firstVisibleItemIndex == 0 && lazyListState.firstVisibleItemScrollOffset < 100
        }
    }

    // Dynamic reaction for status bar and top navigation icons depending on image brightness
    val activity = context as? Activity
    DisposableEffect(isBrightImage, transparentAppBar) {
        if (activity != null && transparentAppBar) {
            val window = activity.window
            val controller = WindowCompat.getInsetsController(window, window.decorView)
            val originalLightStatusBars = controller.isAppearanceLightStatusBars
            controller.isAppearanceLightStatusBars = isBrightImage
            onDispose {
                controller.isAppearanceLightStatusBars = originalLightStatusBars
            }
        } else {
            onDispose {}
        }
    }

    val topBarIconTint by animateColorAsState(
        targetValue = if (transparentAppBar && isBrightImage) Color.Black else Color.White,
        animationSpec = tween(200),
        label = "topBarIconTint"
    )

    LaunchedEffect(libraryArtist) {
        showLocal = libraryArtist?.artist?.isLocal == true
    }

    val playerAwarePadding = LocalPlayerAwareWindowInsets.current.asPaddingValues()
    val layoutDirection = LocalLayoutDirection.current
    val listContentPadding = remember(playerAwarePadding, layoutDirection) {
        PaddingValues(
            start = playerAwarePadding.calculateLeftPadding(layoutDirection),
            top = 0.dp,
            end = playerAwarePadding.calculateRightPadding(layoutDirection),
            bottom = playerAwarePadding.calculateBottomPadding()
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(surfaceColor)
    ) {
        LazyColumn(
            state = lazyListState,
            contentPadding = listContentPadding,
        ) {
            if (artistPage == null && !showLocal) {
                // Shimmer loading state
                item(key = "shimmer") {
                    ShimmerHost {
                        // Hero section placeholder
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 0.dp)
                        ) {
                            // Upper-half artist cover placeholder
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(360.dp)
                                    .shimmer()
                                    .background(MaterialTheme.colorScheme.onSurface)
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            // Artist name placeholder
                            TextPlaceholder(
                                height = 36.dp,
                                modifier = Modifier
                                    .fillMaxWidth(0.6f)
                                    .align(Alignment.CenterHorizontally)
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Stats placeholder
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 48.dp),
                                horizontalArrangement = Arrangement.SpaceEvenly
                            ) {
                                repeat(3) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        TextPlaceholder(
                                            height = 20.dp,
                                            modifier = Modifier.width(40.dp)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        TextPlaceholder(
                                            height = 14.dp,
                                            modifier = Modifier.width(50.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(24.dp))

                            // Buttons placeholder
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 24.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally)
                            ) {
                                ButtonPlaceholder(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                )
                                ButtonPlaceholder(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(32.dp))
                        }

                        // Songs list placeholder
                        repeat(5) {
                            ListItemPlaceHolder()
                        }
                    }
                }
            } else {
                // Hero Header - Upper half cover image with overlaid info, stats and buttons matching reference screenshot
                item(key = "header") {
                    val artistName = artistPage?.artist?.title ?: libraryArtist?.artist?.name

                    BoxWithConstraints(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val coverHeight = (maxHeight * 0.40f).coerceIn(280.dp, 380.dp)

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(coverHeight)
                                .clipToBounds()
                        ) {
                            if (thumbnail != null) {
                                AsyncImage(
                                    model = thumbnail.resize(1200, 1200),
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .graphicsLayer {
                                            scaleX = photoScale
                                            scaleY = photoScale
                                            clip = true
                                        }
                                        .then(
                                            if (!disableBlur && photoBlurDp > 0.5f) Modifier.blur(photoBlurDp.dp) else Modifier
                                        )
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(MaterialTheme.colorScheme.surfaceVariant),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        painter = painterResource(R.drawable.person),
                                        contentDescription = null,
                                        modifier = Modifier.size(96.dp),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                    )
                                }
                            }

                            // Gradient overlay fading from transparent at top to surface background at bottom
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(
                                                Color.Transparent,
                                                Color.Transparent,
                                                surfaceColor.copy(alpha = 0.35f),
                                                surfaceColor.copy(alpha = 0.75f),
                                                surfaceColor.copy(alpha = 0.95f),
                                                surfaceColor
                                            )
                                        )
                                    )
                            )

                            // Overlaid Content (Title, Stats, Action Buttons) at bottom of cover area
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .align(Alignment.BottomCenter)
                                    .padding(horizontal = 24.dp, vertical = 12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                // Artist Name
                                Text(
                                    text = artistName ?: stringResource(R.string.unknown_artist),
                                    style = MaterialTheme.typography.displayMedium,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )

                                // Stats labels
                                val songsLabel = stringResource(R.string.songs)
                                val albumsLabel = stringResource(R.string.albums)
                                val monthlyListenersLabel = stringResource(R.string.monthly_listeners)
                                val subscribersLabel = stringResource(R.string.subscribers)

                                // Stats line 1: Listeners & Subscribers
                                val listenersText = artistPage?.artist?.monthlyListenerCountText?.toArtistCompactCountText()
                                val subscribersText = artistPage?.artist?.subscriberCountText?.toArtistCompactCountText()
                                val line1Parts = remember(listenersText, subscribersText, monthlyListenersLabel, subscribersLabel) {
                                    buildList {
                                        if (!listenersText.isNullOrBlank()) add("$listenersText $monthlyListenersLabel")
                                        if (!subscribersText.isNullOrBlank()) add("$subscribersText $subscribersLabel")
                                    }
                                }
                                if (line1Parts.isNotEmpty()) {
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        text = line1Parts.joinToString(" • "),
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = TextAlign.Center,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                // Stats line 2: Songs & Albums
                                val artistStats = remember(
                                    showLocal,
                                    artistPage,
                                    librarySongs.size,
                                    libraryAlbums.size,
                                    songsLabel,
                                    albumsLabel,
                                    monthlyListenersLabel,
                                    subscribersLabel
                                ) {
                                    buildArtistStats(
                                        showLocal = showLocal,
                                        artistPage = artistPage,
                                        librarySongCount = librarySongs.size,
                                        libraryAlbumCount = libraryAlbums.size,
                                        songsLabel = songsLabel,
                                        albumsLabel = albumsLabel,
                                        monthlyListenersLabel = monthlyListenersLabel,
                                        subscribersLabel = subscribersLabel
                                    )
                                }

                                val songsStat = artistStats.find { it.icon == Icons.Outlined.MusicNote }
                                val albumsStat = artistStats.find { it.icon == Icons.Outlined.Album }
                                val line2Parts = remember(songsStat, albumsStat) {
                                    buildList {
                                        if (songsStat != null) add("${songsStat.value} $songsLabel")
                                        if (albumsStat != null) add("${albumsStat.value} $albumsLabel")
                                    }
                                }
                                if (line2Parts.isNotEmpty()) {
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = line2Parts.joinToString(" • "),
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f),
                                        textAlign = TextAlign.Center,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Spacer(Modifier.height(16.dp))

                                // Action Buttons Row: Shuffle, Play, Subscribe, Radio
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val isSubscribed = libraryArtist?.artist?.bookmarkedAt != null

                                    // 1. Shuffle Circular Button
                                    Surface(
                                        onClick = {
                                            if (!showLocal) {
                                                artistPage?.artist?.shuffleEndpoint?.let { shuffleEndpoint ->
                                                    playerConnection.playQueue(YouTubeQueue(shuffleEndpoint))
                                                }
                                            } else if (librarySongs.isNotEmpty()) {
                                                playerConnection.playQueue(
                                                    ListQueue(
                                                        title = libraryArtist?.artist?.name ?: "Unknown Artist",
                                                        items = librarySongs.shuffled().map { it.toMediaItem() }
                                                    )
                                                )
                                            }
                                        },
                                        enabled = if (showLocal) librarySongs.isNotEmpty() else artistPage?.artist?.shuffleEndpoint != null,
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                        contentColor = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.size(48.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                painter = painterResource(R.drawable.shuffle),
                                                contentDescription = stringResource(R.string.shuffle),
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }

                                    // 2. Main Play Pill Button (White / High contrast)
                                    Surface(
                                        onClick = {
                                            if (!showLocal) {
                                                artistPage?.artist?.shuffleEndpoint?.let { shuffleEndpoint ->
                                                    playerConnection.playQueue(YouTubeQueue(shuffleEndpoint))
                                                }
                                            } else if (librarySongs.isNotEmpty()) {
                                                playerConnection.playQueue(
                                                    ListQueue(
                                                        title = libraryArtist?.artist?.name ?: "Unknown Artist",
                                                        items = librarySongs.map { it.toMediaItem() }
                                                    )
                                                )
                                            }
                                        },
                                        enabled = if (showLocal) librarySongs.isNotEmpty() else artistPage?.artist?.shuffleEndpoint != null,
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        contentColor = MaterialTheme.colorScheme.surface,
                                        modifier = Modifier
                                            .height(48.dp)
                                            .widthIn(min = 110.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center,
                                            modifier = Modifier.padding(horizontal = 20.dp)
                                        ) {
                                            Icon(
                                                painter = painterResource(R.drawable.play),
                                                contentDescription = null,
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Spacer(Modifier.width(8.dp))
                                            Text(
                                                text = stringResource(R.string.play),
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }

                                    // 3. Subscribe Circular Button
                                    Surface(
                                        onClick = {
                                            database.transaction {
                                                val artist = libraryArtist?.artist
                                                if (artist != null) {
                                                    update(artist.toggleLike())
                                                } else {
                                                    artistPage?.artist?.let {
                                                        insert(
                                                            ArtistEntity(
                                                                id = it.id,
                                                                name = it.title,
                                                                channelId = it.channelId,
                                                                thumbnailUrl = it.thumbnail,
                                                            ).toggleLike()
                                                        )
                                                    }
                                                }
                                            }
                                        },
                                        shape = CircleShape,
                                        color = if (isSubscribed)
                                            MaterialTheme.colorScheme.primaryContainer
                                        else
                                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                        contentColor = if (isSubscribed)
                                            MaterialTheme.colorScheme.onPrimaryContainer
                                        else
                                            MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.size(48.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                painter = painterResource(if (isSubscribed) R.drawable.done else R.drawable.add),
                                                contentDescription = stringResource(if (isSubscribed) R.string.subscribed else R.string.subscribe),
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }

                                    // 4. Radio Circular Button
                                    if (!showLocal && artistPage?.artist?.radioEndpoint != null) {
                                        Surface(
                                            onClick = {
                                                artistPage.artist.radioEndpoint?.let { radioEndpoint ->
                                                    playerConnection.playQueue(YouTubeQueue(radioEndpoint))
                                                }
                                            },
                                            shape = CircleShape,
                                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                            contentColor = MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.size(48.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    painter = painterResource(R.drawable.radio),
                                                    contentDescription = stringResource(R.string.radio),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Latest Release Section (if present)
                    val latestReleaseAlbum = remember(artistPage, libraryAlbums) {
                        if (!showLocal) {
                            artistPage?.sections
                                ?.firstOrNull { it.title.contains("latest", ignoreCase = true) || it.title.contains("release", ignoreCase = true) }
                                ?.items?.firstOrNull() as? AlbumItem
                                ?: artistPage?.sections
                                    ?.flatMap { it.items }
                                    ?.filterIsInstance<AlbumItem>()
                                    ?.firstOrNull()
                        } else {
                            libraryAlbums.firstOrNull()?.let {
                                AlbumItem(
                                    browseId = it.album.id,
                                    playlistId = "",
                                    title = it.album.title,
                                    artists = null,
                                    year = it.album.year,
                                    thumbnail = it.album.thumbnailUrl ?: ""
                                )
                            }
                        }
                    }

                    if (latestReleaseAlbum != null) {
                        Spacer(Modifier.height(12.dp))
                        Surface(
                            onClick = {
                                navController.navigate("album/${latestReleaseAlbum.browseId}")
                            },
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 6.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                AsyncImage(
                                    model = latestReleaseAlbum.thumbnail.resize(240, 240),
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(72.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "LATEST RELEASE",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = latestReleaseAlbum.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = "Album${latestReleaseAlbum.year?.let { " • $it" } ?: ""}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    // Artist Description (expandable)
                    val description = artistPage?.description
                    if (!description.isNullOrBlank()) {
                        var isExpanded by rememberSaveable { mutableStateOf(false) }
                        val maxLines = if (isExpanded) Int.MAX_VALUE else 3

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp, vertical = 8.dp)
                                .combinedClickable(
                                    onClick = { isExpanded = !isExpanded },
                                    onLongClick = {}
                                ),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                maxLines = maxLines,
                                overflow = TextOverflow.Ellipsis
                            )

                            if (!isExpanded) {
                                Text(
                                    text = stringResource(R.string.more),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Content sections
                if (showLocal) {
                    // Local Songs Section
                    if (librarySongs.isNotEmpty()) {
                        item {
                            NavigationTitle(
                                title = stringResource(R.string.songs),
                                onClick = {
                                    navController.navigate("artist/${viewModel.artistId}/songs")
                                }
                            )
                        }

                        val filteredLibrarySongs = if (hideExplicit) {
                            librarySongs.filter { !it.song.explicit }
                        } else {
                            librarySongs
                        }

                        itemsIndexed(
                            items = filteredLibrarySongs.take(5),
                            key = { _, item -> "local_song_${item.id}" },
                            contentType = { _, _ -> CONTENT_TYPE_SONG },
                        ) { index, song ->
                            SongListItem(
                                song = song,
                                showInLibraryIcon = true,
                                isActive = song.id == mediaMetadata?.id,
                                isPlaying = isPlaying,
                                trailingContent = {
                                    IconButton(
                                        onClick = {
                                            menuState.show {
                                                SongMenu(
                                                    originalSong = song,
                                                    navController = navController,
                                                    onDismiss = menuState::dismiss,
                                                )
                                            }
                                        },
                                        onLongClick = {},
                                    ) {
                                        Icon(
                                            painter = painterResource(R.drawable.more_vert),
                                            contentDescription = null,
                                        )
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .combinedClickable(
                                        onClick = {
                                            if (song.id == mediaMetadata?.id) {
                                                playerConnection.player.togglePlayPause()
                                            } else {
                                                playerConnection.playQueue(
                                                    ListQueue(
                                                        title = libraryArtist?.artist?.name ?: "Unknown Artist",
                                                        items = librarySongs.map { it.toMediaItem() },
                                                        startIndex = index
                                                    )
                                                )
                                            }
                                        },
                                        onLongClick = {
                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                            menuState.show {
                                                SongMenu(
                                                    originalSong = song,
                                                    navController = navController,
                                                    onDismiss = menuState::dismiss,
                                                )
                                            }
                                        },
                                    )
                                    .animateItem(),
                            )
                        }

                        // Show "View All" if more songs available
                        if (filteredLibrarySongs.size > 5) {
                            item {
                                Surface(
                                    onClick = {
                                        navController.navigate("artist/${viewModel.artistId}/songs")
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 8.dp)
                                ) {
                                    Text(
                                        text = stringResource(R.string.view_all),
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 12.dp),
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }

                    // Local Albums Section
                    if (libraryAlbums.isNotEmpty()) {
                        item {
                            NavigationTitle(
                                title = stringResource(R.string.albums),
                                onClick = {
                                    navController.navigate("artist/${viewModel.artistId}/albums")
                                }
                            )
                        }

                        item {
                            val filteredLibraryAlbums = if (hideExplicit) {
                                libraryAlbums.filter { !it.album.explicit }
                            } else {
                                libraryAlbums
                            }

                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 12.dp),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                items(
                                    items = filteredLibraryAlbums,
                                    key = { album -> "local_album_${album.id}" },
                                    contentType = { CONTENT_TYPE_ALBUM },
                                ) { album ->
                                    AlbumGridItem(
                                        album = album,
                                        isActive = mediaMetadata?.album?.id == album.id,
                                        isPlaying = isPlaying,
                                        coroutineScope = coroutineScope,
                                        modifier = Modifier
                                            .combinedClickable(
                                                onClick = {
                                                    navController.navigate("album/${album.id}")
                                                },
                                                onLongClick = {
                                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                    menuState.show {
                                                        AlbumMenu(
                                                            originalAlbum = album,
                                                            navController = navController,
                                                            onDismiss = menuState::dismiss
                                                        )
                                                    }
                                                }
                                            )
                                            .animateItem()
                                    )
                                }
                            }
                        }
                    }
                } else {
                    // YouTube/Remote content sections
                    artistPage?.sections?.fastForEach { section ->
                        if (section.items.isNotEmpty()) {
                            item(
                                key = "youtube_section_header_${section.title}_${section.items.firstOrNull()?.id.orEmpty()}_${section.moreEndpoint?.browseId.orEmpty()}",
                                contentType = CONTENT_TYPE_HEADER,
                            ) {
                                NavigationTitle(
                                    title = section.title,
                                    onClick = section.moreEndpoint?.let {
                                        {
                                            navController.navigate(buildArtistItemsRoute(viewModel.artistId, it))
                                        }
                                    },
                                )
                            }
                        }

                        if (section.layout == ArtistSectionLayout.LIST && section.items.all { it is SongItem }) {
                            items(
                                items = section.items.distinctBy { it.id },
                                key = { "youtube_song_${it.id}" },
                                contentType = { CONTENT_TYPE_SONG },
                            ) { song ->
                                YouTubeListItem(
                                    item = song as SongItem,
                                    isActive = mediaMetadata?.id == song.id,
                                    isPlaying = isPlaying,
                                    trailingContent = {
                                        IconButton(
                                            onClick = {
                                                menuState.show {
                                                    YouTubeSongMenu(
                                                        song = song,
                                                        navController = navController,
                                                        onDismiss = menuState::dismiss,
                                                    )
                                                }
                                            },
                                            onLongClick = {},
                                        ) {
                                            Icon(
                                                painter = painterResource(R.drawable.more_vert),
                                                contentDescription = null,
                                            )
                                        }
                                    },
                                    modifier = Modifier
                                        .combinedClickable(
                                            onClick = {
                                                if (song.id == mediaMetadata?.id) {
                                                    playerConnection.player.togglePlayPause()
                                                } else {
                                                    playerConnection.playQueue(
                                                        YouTubeQueue(
                                                            WatchEndpoint(videoId = song.id),
                                                            song.toMediaMetadata()
                                                        ),
                                                    )
                                                }
                                            },
                                            onLongClick = {
                                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                menuState.show {
                                                    YouTubeSongMenu(
                                                        song = song,
                                                        navController = navController,
                                                        onDismiss = menuState::dismiss,
                                                    )
                                                }
                                            },
                                        )
                                        .animateItem(),
                                )
                            }
                        } else {
                            item(
                                key = "youtube_section_grid_${section.title}_${section.items.firstOrNull()?.id.orEmpty()}_${section.moreEndpoint?.browseId.orEmpty()}",
                                contentType = CONTENT_TYPE_LIST,
                            ) {
                                LazyRow(
                                    contentPadding = PaddingValues(horizontal = 12.dp),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    items(
                                        items = section.items.distinctBy { it.id },
                                        key = {
                                            val type = when (it) {
                                                is SongItem -> "song"
                                                is AlbumItem -> "album"
                                                is ArtistItem -> "artist"
                                                is PlaylistItem -> "playlist"
                                                else -> "item"
                                            }
                                            "youtube_${type}_${it.id}"
                                        },
                                        contentType = {
                                            when (it) {
                                                is SongItem -> CONTENT_TYPE_SONG
                                                is AlbumItem -> CONTENT_TYPE_ALBUM
                                                is ArtistItem -> CONTENT_TYPE_ARTIST
                                                is PlaylistItem -> CONTENT_TYPE_PLAYLIST
                                                else -> CONTENT_TYPE_LIST
                                            }
                                        },
                                    ) { item ->
                                        YouTubeGridItem(
                                            item = item,
                                            isActive = when (item) {
                                                is SongItem -> mediaMetadata?.id == item.id
                                                is AlbumItem -> mediaMetadata?.album?.id == item.id
                                                else -> false
                                            },
                                            isPlaying = isPlaying,
                                            coroutineScope = coroutineScope,
                                            modifier = Modifier
                                                .combinedClickable(
                                                    onClick = {
                                                        when (item) {
                                                            is SongItem ->
                                                                playerConnection.playQueue(
                                                                    YouTubeQueue(
                                                                        WatchEndpoint(videoId = item.id),
                                                                        item.toMediaMetadata()
                                                                    ),
                                                                )

                                                            is AlbumItem -> navController.navigate("album/${item.id}")
                                                            is ArtistItem -> navController.navigate("artist/${item.id}")
                                                            is PlaylistItem -> navController.navigate("online_playlist/${item.id}")
                                                        }
                                                    },
                                                    onLongClick = {
                                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                        menuState.show {
                                                            when (item) {
                                                                is SongItem ->
                                                                    YouTubeSongMenu(
                                                                        song = item,
                                                                        navController = navController,
                                                                        onDismiss = menuState::dismiss,
                                                                    )

                                                                is AlbumItem ->
                                                                    YouTubeAlbumMenu(
                                                                        albumItem = item,
                                                                        navController = navController,
                                                                        onDismiss = menuState::dismiss,
                                                                    )

                                                                is ArtistItem ->
                                                                    YouTubeArtistMenu(
                                                                        artist = item,
                                                                        onDismiss = menuState::dismiss,
                                                                    )

                                                                is PlaylistItem ->
                                                                    YouTubePlaylistMenu(
                                                                        playlist = item,
                                                                        coroutineScope = coroutineScope,
                                                                        onDismiss = menuState::dismiss,
                                                                    )
                                                            }
                                                        }
                                                    },
                                                )
                                                .animateItem(),
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Bottom spacing
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }

        // FAB for switching between local/remote view
        HideOnScrollFAB(
            visible = librarySongs.isNotEmpty() && libraryArtist?.artist?.isLocal != true,
            lazyListState = lazyListState,
            icon = if (showLocal) R.drawable.language else R.drawable.library_music,
            label = if (showLocal) stringResource(R.string.together_online) else stringResource(R.string.filter_library),
            onClick = {
                showLocal = showLocal.not()
                if (!showLocal && artistPage == null) viewModel.fetchArtistsFromYTM()
            }
        )

        // Snackbar
        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .windowInsetsPadding(LocalPlayerAwareWindowInsets.current)
                .align(Alignment.BottomCenter)
        )
    }

    // Top App Bar
    TopAppBar(
        title = {
            val animatedAlpha by animateFloatAsState(
                targetValue = if (!transparentAppBar) 1f else 0f,
                animationSpec = tween(200),
                label = "titleAlpha"
            )
            Text(
                text = artistPage?.artist?.title ?: libraryArtist?.artist?.name ?: "",
                modifier = Modifier.alpha(animatedAlpha),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        },
        navigationIcon = {
            IconButton(
                onClick = navController::navigateUp,
                onLongClick = navController::backToMain,
            ) {
                Icon(
                    painterResource(R.drawable.arrow_back),
                    contentDescription = null,
                    tint = topBarIconTint,
                )
            }
        },
        actions = {
            // Share/Copy link button
            IconButton(
                onClick = {
                    viewModel.artistPage?.artist?.shareLink?.let { link ->
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("Artist Link", link)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, R.string.link_copied, Toast.LENGTH_SHORT).show()
                    }
                },
                onLongClick = {},
            ) {
                Icon(
                    painterResource(R.drawable.link),
                    contentDescription = null,
                    tint = topBarIconTint,
                )
            }

            // Share button
            IconButton(
                onClick = {
                    val shareIntent = Intent().apply {
                        action = Intent.ACTION_SEND
                        type = "text/plain"
                        putExtra(
                            Intent.EXTRA_TEXT,
                            viewModel.artistPage?.artist?.shareLink
                                ?: "https://music.youtube.com/channel/${viewModel.artistId}"
                        )
                    }
                    context.startActivity(Intent.createChooser(shareIntent, null))
                },
                onLongClick = {},
            ) {
                Icon(
                    painter = painterResource(R.drawable.share),
                    contentDescription = null,
                    tint = topBarIconTint,
                )
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Color.Transparent,
            scrolledContainerColor = Color.Transparent,
        )
    )
}

@Immutable
private data class ArtistStatItemUiModel(
    val icon: ImageVector,
    val value: String,
    val contentDescription: String,
)

@Composable
private fun ArtistStatsButtonGroup(
    stats: List<ArtistStatItemUiModel>,
    modifier: Modifier = Modifier,
) {
    val buttonShapes = ButtonDefaults.shapes()

    FlowRow(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp, horizontal = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        stats.fastForEach { stat ->
            FilledTonalButton(
                onClick = NoOpStatButtonClick,
                shapes = buttonShapes,
                contentPadding = PaddingValues(horizontal = 14.dp),
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .widthIn(min = 72.dp)
                    .semantics(mergeDescendants = true) {
                        contentDescription = stat.contentDescription
                    },
            ) {
                Icon(
                    imageVector = stat.icon,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = stat.value,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                )
            }
        }
    }
}

private fun buildArtistStats(
    showLocal: Boolean,
    artistPage: ArtistPage?,
    librarySongCount: Int,
    libraryAlbumCount: Int,
    songsLabel: String,
    albumsLabel: String,
    monthlyListenersLabel: String,
    subscribersLabel: String,
): List<ArtistStatItemUiModel> {
    val songSections = artistPage?.sections?.filter { section ->
        section.items.any { it is SongItem }
    }
    val songCount = if (showLocal) {
        librarySongCount
    } else {
        songSections
            ?.asSequence()
            ?.flatMap { it.items.asSequence() }
            ?.filterIsInstance<SongItem>()
            ?.distinctBy { it.id }
            ?.count() ?: librarySongCount
    }
    val hasMoreSongs = !showLocal && songSections?.any { it.moreEndpoint != null } == true

    val albumSections = artistPage?.sections?.filter { section ->
        section.items.any { it is AlbumItem }
    }
    val albumCount = if (showLocal) {
        libraryAlbumCount
    } else {
        albumSections
            ?.asSequence()
            ?.flatMap { it.items.asSequence() }
            ?.filterIsInstance<AlbumItem>()
            ?.distinctBy { it.id }
            ?.count() ?: libraryAlbumCount
    }
    val hasMoreAlbums = !showLocal && albumSections?.any { it.moreEndpoint != null } == true

    return buildList {
        if (songCount > 0) {
            val value = compactCountText(songCount, hasMoreSongs)
            add(
                ArtistStatItemUiModel(
                    icon = Icons.Outlined.MusicNote,
                    value = value,
                    contentDescription = "$songsLabel $value",
                )
            )
        }

        if (albumCount > 0) {
            val value = compactCountText(albumCount, hasMoreAlbums)
            add(
                ArtistStatItemUiModel(
                    icon = Icons.Outlined.Album,
                    value = value,
                    contentDescription = "$albumsLabel $value",
                )
            )
        }

        artistPage?.artist?.monthlyListenerCountText?.toArtistCompactCountText()?.let { value ->
            add(
                ArtistStatItemUiModel(
                    icon = Icons.Outlined.Hearing,
                    value = value,
                    contentDescription = "$monthlyListenersLabel $value",
                )
            )
        }

        artistPage?.artist?.subscriberCountText?.toArtistCompactCountText()?.let { value ->
            add(
                ArtistStatItemUiModel(
                    icon = Icons.Outlined.PersonAdd,
                    value = value,
                    contentDescription = "$subscribersLabel $value",
                )
            )
        }
    }
}

private fun compactCountText(count: Int, hasMore: Boolean): String {
    val value = formatCompactCount(count.toLong())
    return if (hasMore) "$value+" else value
}

private val CompactArtistCountPattern = Regex("""\d+(?:[.,]\d+)?\s*[KMB]""", RegexOption.IGNORE_CASE)
private val ArtistCountPattern = Regex("""\d+(?:[.,]\d+)*""")
private val NoOpStatButtonClick: () -> Unit = {}

private fun String.toArtistCompactCountText(): String? {
    val compactText = CompactArtistCountPattern.find(this)?.value
    if (compactText != null) {
        return compactText
            .filterNot { it.isWhitespace() }
            .replace(',', '.')
            .uppercase(Locale.US)
    }

    val count = ArtistCountPattern.find(this)
        ?.value
        ?.filter { it.isDigit() }
        ?.toLongOrNull()
        ?: return null

    return formatCompactCount(count)
}

private fun calculateTopLuminanceIsBright(bitmap: android.graphics.Bitmap): Boolean {
    val width = bitmap.width
    val height = (bitmap.height * 0.35f).toInt().coerceAtLeast(1)
    var totalLuminance = 0.0
    var count = 0
    val step = 4
    for (x in 0 until width step step) {
        for (y in 0 until height step step) {
            val pixel = bitmap.getPixel(x, y)
            val r = android.graphics.Color.red(pixel) / 255.0
            val g = android.graphics.Color.green(pixel) / 255.0
            val b = android.graphics.Color.blue(pixel) / 255.0
            val luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b
            totalLuminance += luminance
            count++
        }
    }
    return if (count > 0) (totalLuminance / count) > 0.55 else false
}

private fun buildArtistItemsRoute(
    artistId: String,
    endpoint: BrowseEndpoint,
): String {
    val encodedArtistId = Uri.encode(artistId)
    val encodedBrowseId = Uri.encode(endpoint.browseId)
    val encodedParams = endpoint.params
        ?.takeIf { it.isNotBlank() }
        ?.let { Uri.encode(it) }

    return buildString {
        append("artist/")
        append(encodedArtistId)
        append("/items?browseId=")
        append(encodedBrowseId)
        if (encodedParams != null) {
            append("&params=")
            append(encodedParams)
        }
    }
}
