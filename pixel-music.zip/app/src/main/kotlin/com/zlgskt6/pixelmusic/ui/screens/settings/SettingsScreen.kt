/*
 * Pixel Music (2026)
 * © zlgskt6 — github.com/zlgskt6
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 *
 * Based on ArchiveTune (2026)
 * © Rukamori — github.com/rukamori
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package com.zlgskt6.pixelmusic.ui.screens.settings

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Icon
import androidx.compose.material3.LargeFlexibleTopAppBar
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.TopAppBarScrollBehavior
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.zlgskt6.pixelmusic.BuildConfig
import com.zlgskt6.pixelmusic.LocalPlayerAwareWindowInsets
import com.zlgskt6.pixelmusic.R
import com.zlgskt6.pixelmusic.ui.component.IconButton
import com.zlgskt6.pixelmusic.ui.utils.backToMain
import com.zlgskt6.pixelmusic.utils.Updater

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    navController: NavController,
    scrollBehavior: TopAppBarScrollBehavior? = null,
    latestVersionName: String,
    onClearUpdateBadge: () -> Unit = {},
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface),
    ) {
        SettingsScreenContent(
            navController = navController,
            latestVersionName = latestVersionName,
            onClearUpdateBadge = onClearUpdateBadge,
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(
                    LocalPlayerAwareWindowInsets.current.only(
                        WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom + WindowInsetsSides.Top,
                    ),
                ),
        )
    }
}

@Composable
fun SettingsScreenContent(
    navController: NavController,
    latestVersionName: String,
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(top = 12.dp, bottom = 32.dp),
    onClearUpdateBadge: () -> Unit = {},
) {
    val context = LocalContext.current
    val isAndroid12OrLater = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val listState = rememberLazyListState()

    val storagePermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    val notificationPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.POST_NOTIFICATIONS
    } else {
        null
    }

    var isStorageGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, storagePermission) == PackageManager.PERMISSION_GRANTED
        )
    }

    var isNotificationGranted by remember {
        mutableStateOf(
            notificationPermission == null ||
                ContextCompat.checkSelfPermission(context, notificationPermission) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        isStorageGranted = result[storagePermission] == true || isStorageGranted
        if (notificationPermission != null) {
            isNotificationGranted = result[notificationPermission] == true || isNotificationGranted
        }
    }

    val shouldShowPermissionHint = !isStorageGranted || !isNotificationGranted
    val hasUpdate = BuildConfig.UPDATER_AVAILABLE &&
        !Updater.isSameVersion(latestVersionName, BuildConfig.VERSION_NAME)
    var isUpdateDismissed by remember { mutableStateOf(false) }
    val settingsGroups = buildSettingsGroups(navController, isAndroid12OrLater, hasUpdate, context)
    val settingsItems = remember(settingsGroups) {
        settingsGroups.flatMap { it.items }
    }

    LazyColumn(
        state = listState,
        verticalArrangement = Arrangement.spacedBy(2.dp),
        modifier = modifier,
        contentPadding = contentPadding,
    ) {
        item(key = "profile_header", contentType = "settings_profile") {
            SettingsProfileHeader(
                navController = navController,
                modifier = Modifier
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 12.dp),
            )
        }

        if (hasUpdate && !isUpdateDismissed) {
            item(key = "update", contentType = "settings_banner") {
                SettingsUpdateBanner(
                    latestVersion = latestVersionName,
                    onClick = { navController.navigate("settings/update") },
                    onDismiss = { isUpdateDismissed = true },
                    modifier = Modifier
                        .padding(horizontal = SettingsDimensions.ScreenHorizontalPadding)
                        .padding(bottom = SettingsDimensions.SectionSpacing),
                )
            }
        }

        if (shouldShowPermissionHint) {
            item(key = "permission", contentType = "settings_banner") {
                SettingsPermissionBanner(
                    onRequestPermission = {
                        val toRequest = buildList {
                            if (!isStorageGranted) add(storagePermission)
                            if (!isNotificationGranted && notificationPermission != null) {
                                add(notificationPermission)
                            }
                        }
                        if (toRequest.isNotEmpty()) {
                            permissionLauncher.launch(toRequest.toTypedArray())
                        }
                    },
                    modifier = Modifier
                        .padding(horizontal = SettingsDimensions.ScreenHorizontalPadding)
                        .padding(bottom = SettingsDimensions.SectionSpacing),
                )
            }
        }

        itemsIndexed(
            items = settingsItems,
            key = { _, item -> item.key },
            contentType = { _, _ -> "settings_segment" },
        ) { index, settingsItem ->
            SettingsSegmentedItem(
                item = settingsItem,
                index = index,
                count = settingsItems.size,
                modifier = Modifier.padding(horizontal = 26.dp),
            )
        }

        item(key = "bottom_spacer", contentType = "settings_spacer") {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
